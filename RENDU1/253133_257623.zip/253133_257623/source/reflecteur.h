/*
    Fichier:    main.c
    Auteur:     Alix Nepveux & Sven Borden
    Date :      16 mars 2016
    Version:    0.9
    Description:Module reflecteur qui gere la structure 
*/

#ifndef REFLECTEUR_H
#define REFLECTEUR_H

//verifie les valeurs et les enregistre dans la structure
int reflecteurSet(char[]);

#endif

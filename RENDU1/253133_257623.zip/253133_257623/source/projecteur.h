/*
    Fichier:    main.c
    Auteur:     Alix Nepveux & Sven Borden
    Date :      16 mars 2016
    Version:    0.9
    Description:Module projecteur qui gere la structure
*/

#ifndef PROJECTEUR_H
#define PROJECTEUR_H

//verifie les valeurs et les enregistre dans la structure
int projecteurSet(char[]);

#endif

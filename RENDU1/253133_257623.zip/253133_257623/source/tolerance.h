/* Nom: tolerance.h
 * Description: intervalle de tolérance admis
 * Date: 03.02.2014
 * version : 1.0
 * Auteur: PROG II
 */

#ifndef TOLERANCE_H
#define TOLERANCE_H

#define EPSILON_ZERO 1e-9

#endif

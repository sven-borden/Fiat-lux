/*
    Fichier:    main.c
    Auteur:     Alix Nepveux & Sven Borden
    Date :      16 mars 2016
    Version:    0.9
    Description:Module photon qui gere la structure photon 
*/

#ifndef PHOTON_H
#define PHOTON_H

//verifie les valeurs et les enregistre dans la structure
int photonSet(char[]);

#endif

/*
    Fichier:    main.c
    Auteur:     Alix Nepveux & Sven Borden
    Date :      16 mars 2016
    Version:    0.9
    Description:Module de simulation du projet de Programation II MT
*/
#ifndef MODELE_H
#define MODELE_H

#define MAX_FILE    80

//lis les donnees et dispatch les informations dans les sous modules
int modeleLecture(char fileName[MAX_FILE]);

#endif

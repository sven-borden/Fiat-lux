/*
	Fichier:	lecture.h$
	Auteurs:	Alix Nepveux & Sven Borden
	Date:		20 avril 2016
	Version:	1.1
	Description:	Module qui lit un fichier et vérifie des erreurs simple
*/

#ifndef LECTURE_H
#define LECTURE_H

int lecture(char* fileName);

#endif

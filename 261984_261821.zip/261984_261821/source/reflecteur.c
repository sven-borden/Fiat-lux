// fichier: reflecteur.c
// date: 08.04.2016
// description du module: fonctions liées aux reflecteurs
//-------------------------------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "absorbeur.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "modele.h"
#include "photon.h"
#include "projecteur.h"
#include "reflecteur.h"
#include "utilitaire.h"
#define NB_ELEM	   4
#define NB_REFL    1
#define ERR_R	   2
#define FAUX 	   0
#define VRAI       1


struct refl{
	double deb_x;
	double deb_y;
	double fin_x;
	double fin_y;
	int nb_element; 
	short selection;
	REFL *suivant;
	double vect_x; 
	double vect_y; 
	double unit_x;
	double unit_y;
	double norme; 
	double normal_x;
	double normal_y;
};

static REFL * p_tete = NULL;
static int nb_refl = 0;


int reflecteur_decodage(char *tab, int *ptr_nb_r, int i)
{	
	if(i == 0)
	{
		if(sscanf(tab,"%d", ptr_nb_r) != NB_REFL) 
		{
			error_lect_nb_elements(ERR_REFLECTEUR); 			
			return 1;
		}
		nb_refl = *ptr_nb_r;
		return 0;
	}
	
	REFL * data = NULL;
	
	data = reflecteur_liste_ajouter();
	data->nb_element = i;
	data->selection = FAUX;
	
	if(sscanf(tab, "%lf %lf %lf %lf", &data->deb_x, &data->deb_y, &data->fin_x, 
	   &data->fin_y) != NB_ELEM) 
	{
		error_lecture_elements(ERR_REFLECTEUR, ERR_PAS_ASSEZ);
		return 1;
	}
	
	if (points_trop_proche(data->deb_x, data->deb_y, data->fin_x, data->fin_y)
		<= EPSIL_CREATION)
	{
		error_lecture_point_trop_proche(ERR_REFLECTEUR, i-1); 
		return 1;
	}	
	reflecteur_creation_vecteur();
	
	return 0;		
}

REFL * reflecteur_liste_ajouter()
{
	REFL * e1 = NULL;
	if(!(e1 = malloc(sizeof(REFL))))
	{
		printf("Pb d'allocation dans %s\n", __func__);
		exit(EXIT_FAILURE);
	}
	e1->suivant = p_tete;
	p_tete = e1;
	return e1;
}

int reflecteur_creation(double deb_x, double deb_y, double fin_x, double fin_y)
{
	int nb_r = modele_nb_r();
	static int i = 1;
	REFL * data = NULL;
	
	data = reflecteur_liste_ajouter();
	data->deb_x = deb_x;
	data->deb_y = deb_y;
	data->fin_x = fin_x;
	data->fin_y = fin_y;
	data->nb_element = nb_refl + i; 
	data->selection = FAUX;
	nb_r++;
	modele_modif_nb_element(nb_r, REFLECTEUR);
	if(absorbeur_verification_2(data->deb_x, data->deb_y, data->fin_x, 
								data->fin_y, REFLECTEUR, data->nb_element) ||
	   projecteur_verification_2(data->deb_x, data->deb_y, data->fin_x, 
								 data->fin_y, REFLECTEUR, data->nb_element) ||
	   reflecteur_verification(nb_r))
	{
		data->selection = VRAI;
		reflecteur_suppr_selectionne(nb_r);
		return 1;
	}
	i++;
	return 0;
}

void reflecteur_liste_retirer(REFL *e1)
{
	REFL * precedent = p_tete;
	REFL * actuel = p_tete;
	
	while(actuel != e1 && actuel)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
}

void reflecteur_vider_liste()
{
	// Retire un à un les elements en tete de la liste 
	REFL *e1;
	while (p_tete)
	{
		e1 = p_tete;
		reflecteur_liste_retirer(e1);
	}
	p_tete = NULL;
}

/*void reflecteur_liste_effacer()
{
	REFL * precedent = p_tete;
	REFL * actuel = p_tete;
	
	while(actuel && actuel->suivant)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
	p_tete = NULL;
}*/

double reflecteur_pt_plus_proche(double x, double y)
{
	reflecteur_deselection();
	// verifier si reflecteur
	if(!p_tete)
		return 0; 
	
	REFL *reflecteur = p_tete;
	REFL *selectionne = NULL;
	
	double d1 = 0, d2 = 0;
	double d_min = sqrt(pow((x - reflecteur->deb_x),2) + 
				   pow((y - reflecteur->deb_y),2));
	
	while(reflecteur)
	{
		d1 = sqrt(pow((x - reflecteur->deb_x),2) + pow((y - reflecteur->deb_y),2));
		d2 = sqrt(pow((x - reflecteur->fin_x),2) + pow((y - reflecteur->fin_y),2));
		if(d1 <= d_min)
		{
			d_min = d1;
			selectionne = reflecteur;
		}
		if(d2 <= d_min)
		{
			d_min = d2;
			selectionne = reflecteur;
		}
		reflecteur = reflecteur->suivant;		
	}
		
	selectionne->selection = VRAI;
	
	return d_min;
}

int reflecteur_deselection()
{
	// verifier si reflecteur
	if(!p_tete)
		return 0;
		
	REFL *reflecteur;
	reflecteur = p_tete;
	
	while(reflecteur)
	{
		if (reflecteur->selection == VRAI)
		{
			reflecteur->selection = FAUX;
		}
		reflecteur = reflecteur->suivant;
	}
	
	return 0;
}

int reflecteur_suppr_selectionne(nb_r)
{
	// verifie si reflecteur
	if(!p_tete)
		return 0;
		
	REFL *reflecteur;
	reflecteur = p_tete;
	
	while(reflecteur)
	{
		if (reflecteur->selection) 
		{
			reflecteur_supprimer(reflecteur, nb_r);
			return 0 ;
		}

		reflecteur = reflecteur->suivant;
	}
	return 0;
}

int reflecteur_supprimer(REFL *a_supprimer, int nb_r)
{
	// verifie si reflecteur
	if(!p_tete)
		return 1;
		
	// cas où le reflecteur est le premier element
	if(a_supprimer == p_tete)
	{
		p_tete = a_supprimer->suivant;
		free(a_supprimer);
		nb_r--;
		modele_modif_nb_element(nb_r, REFLECTEUR);
		return 1;
	}
		
	// autres cas
	REFL *reflecteur;
	reflecteur = p_tete;
	
	while(reflecteur)
	{
		if(reflecteur->suivant == a_supprimer)
		{
			reflecteur->suivant = a_supprimer->suivant;
			free(a_supprimer);
			nb_r--;
			modele_modif_nb_element(nb_r, REFLECTEUR);
			return 1;
		}
		reflecteur = (reflecteur->suivant);
	}
	return 0;
}


void reflecteur_creation_vecteur ()
{
	REFL * courant = p_tete;

    while(courant)
    {
		courant->vect_x = courant->fin_x - courant->deb_x;
		courant->vect_y = courant->fin_y - courant->deb_y;
    
		courant->norme = sqrt (pow (courant->vect_x, 2) + 
							   pow (courant->vect_y, 2));
    
		//vecteur unitaire 
		courant->unit_x = courant->vect_x / courant->norme;
		courant->unit_y = courant->vect_y / courant->norme;
    
		//vecteur normal
    
		courant->normal_x = - courant->unit_y;
		courant->normal_y = courant->unit_x;
		
		courant = courant->suivant;
	}
}


void reflecteur_affichage()
{
	const float rouge[3] = {1., 0., 0.};
	graphic_set_color3fv(rouge);
	
	REFL * actuel = p_tete;
	
	while(actuel)
	{
		if(actuel->selection == VRAI)
		{
			graphic_set_line_width(4.);
		}
		else
		{
			graphic_set_line_width(2.);
		}
		graphic_draw_segment (actuel->deb_x, actuel->deb_y, actuel->fin_x, 
							  actuel->fin_y);
		actuel = actuel->suivant;
	}
}


/*****************************************************************/

void reflecteur_get_lineseg(int *i, int *m, double *r1_x, double *r1_y, 
							double *r2_x, double *r2_y)
{
	REFL * actuel = p_tete;
	
	while(actuel && actuel->nb_element != *i) 
	{
		*r1_x = actuel->deb_x;
		*r1_y = actuel->deb_y;
		*r2_x = actuel->fin_x;
		*r2_y = actuel->fin_y;
		*m = actuel->nb_element; 
		actuel = actuel->suivant;
	}
	(*i)++;
}


short reflecteur_verification(int nb_r) 
{ 
	REFL * actuel1 = p_tete;
	REFL * actuel2 =  actuel1->suivant;
	
	while (actuel1)
	{	
		while (actuel2)
		{
			if(utilitaire_superposition(actuel1->deb_x, actuel1->deb_y, 
									   actuel1->fin_x, actuel1->fin_y,
									   actuel2->deb_x, actuel2->deb_y, 
									   actuel2->fin_x, actuel2->fin_y, 
									   EPSIL_CREATION))
									   
			{
				error_lecture_intersection(ERR_REFLECTEUR, actuel1->nb_element-1,
										   ERR_REFLECTEUR, actuel2->nb_element-1);
				return 1;
			}
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
	}
	return 0;
}


int reflecteur_verification_2(double deb_x, double deb_y, double fin_x, 
					          double fin_y, int etat, int i)
{
	REFL * actuel = p_tete;
	
	while(actuel)
	{
		if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel->deb_x, 
									actuel->deb_y, actuel->fin_x, 
								    actuel->fin_y, EPSIL_CONTACT) == 1)
		{
			error_lecture_intersection(etat, i-1, ERR_REFLECTEUR, 
									   actuel->nb_element-1);
			return 1;            
		}
	}
	return 0;
}

int reflecteur_verification_3(double deb_x, double deb_y, double fin_x, 
					          double fin_y, int etat, int i, double *d_r, 
							  double *r_deb_x, double *r_deb_y, 
					          double *r_fin_x, double *r_fin_y, int *cas_critique)
{
	REFL * actuel = p_tete;
	double d1 = 0, x1 = 0, y1 = 0;
	int intersection = 0, valeur = 0;
	*cas_critique = 0;
	
	while(actuel)
	{
		if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel->deb_x, 
								   actuel->deb_y, actuel->fin_x, 
								   actuel->fin_y, EPSILON_ZERO) == 1)
		{
			photon_intersection (deb_x, deb_y, fin_x, fin_y, actuel->deb_x, 
								 actuel->deb_y, actuel->fin_x, actuel->fin_x, 
								 &x1, &y1);
			d1 = photon_distance_reflecteur (x1, y1, deb_x, deb_y);
			valeur = 1;
		}
	
		if (d1 < EPSILON_ZERO && valeur == 1)
		{
			*cas_critique = 1;
		}	
			
		if (d1 < *d_r && *cas_critique == 0 && valeur == 1)
		{
			*d_r = d1;
			*r_deb_x = actuel->deb_x;
			*r_deb_y = actuel->deb_y;
			*r_fin_x = actuel->fin_x;
			*r_fin_y = actuel->fin_y;
			intersection = 1;
		}
		actuel = actuel->suivant;
	}		
	if(intersection == 1) return 1;
	return 0;
}

void save_refl(FILE * fichier)
{
	REFL * actuel = p_tete;
	
	fprintf(fichier, "#reflecteurs\n");
	if(actuel)
	{
		fprintf (fichier, "%d\n", actuel->nb_element);
	}
	while(actuel)
	{
		fprintf(fichier, "%f %f %f %f\n", actuel->deb_x, actuel->deb_y, 
				actuel->fin_x, actuel->fin_y);
		actuel = actuel->suivant;
	}
	
	fprintf(fichier, "FIN_LISTE\n\n");
}

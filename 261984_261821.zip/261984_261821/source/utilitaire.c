// fichier: utilitaire.c
// date: 08.04.2016
// description du module: fonctions de vérifications/erreurs
//-------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "constantes.h"
#include "error.h"
#include "utilitaire.h"


double points_trop_proche(double x1, double y1, double x2, double y2)
{
	double d = 0;
	d = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
	return d;
}

/***********************************************************************/
short utilitaire_superposition(double a1_x, double a1_y, double a2_x, 
							  double a2_y, double b1_x, double b1_y,
							  double b2_x, double b2_y, double tolerance) 

{
	VECTEUR v1   = utilitaire_coor_vecteur(a1_x, a1_y, a2_x, a2_y);
	VECTEUR v2   = utilitaire_coor_vecteur(b1_x, b1_y, b2_x, b2_y);
	double norm1 = utilitaire_norm(v1);
	double norm2 = utilitaire_norm(v2);
	VECTEUR u1   = utilitaire_unitaire(v1, norm1);
	VECTEUR u2   = utilitaire_unitaire(v2, norm2);
	VECTEUR a1b1 = utilitaire_coor_vecteur(a1_x, a1_y, b1_x, b1_y);
	VECTEUR a1b2 = utilitaire_coor_vecteur(a1_x, a1_y, b2_x, b2_y);
	VECTEUR b1a2 = utilitaire_coor_vecteur(b1_x, b1_y, a2_x, a2_y);
	
	// segments paralleles et eventuellement colineaires ou superposes
	if(fabs(utilitaire_produit_vectoriel(u1, u2)) <= EPSIL_PARAL) 
	{
		double vpbegin = utilitaire_produit_vectoriel(u1, utilitaire_unitaire(a1b1,
													  utilitaire_norm(a1b1)));
		// segments colineaires eventuellement superposes
		if(fabs(vpbegin) <= EPSIL_PARAL) 
		{
			// superposition determinee selon signe des x.scalaires
			double spu1v2  = utilitaire_produit_scalaire(u1, v2);
			double spbegin = utilitaire_produit_scalaire(u1, a1b1);
			if(fabs(spu1v2) < EPSIL_PARAL)
			{
				if(spbegin > 0) // pas de superposition
				{
					if(spbegin + spu1v2 > norm1 + tolerance)
						return 0;
				}
				else if(spbegin < -tolerance) // superposition
					return 0;
			}
			else
			{
				if(spbegin > 0) // pas de superposition
				{
					if(spbegin > norm1 + tolerance)
						return 0;
				}
				else if(spbegin + spu1v2 < -tolerance)// superposition
					return 0;
			}
			return 0; 
		}
		else
			return 0;
	}
	else
		return utilitaire_intersection(a1b2, b1a2, a1b1, u1, u2, tolerance);
}


VECTEUR utilitaire_coor_vecteur(double x1, double y1, 
								double x2, double y2)
{
	VECTEUR v = {x2 - x1, y2 - y1};
	return v;
}

double utilitaire_norm(VECTEUR v)
{
	return sqrt(v.x * v.x + v.y * v.y);
}

VECTEUR utilitaire_unitaire(VECTEUR v, double norm)
{
	VECTEUR u = {v.x / norm, v.y / norm};
	return u;
}


double utilitaire_produit_vectoriel(VECTEUR v1, VECTEUR v2)
{
	return v1.x * v2.y - v1.y * v2.x;
}

double utilitaire_produit_scalaire(VECTEUR v1, VECTEUR v2)
{
	return v1.x * v2.x + v1.y * v2.y;
}

short utilitaire_intersection(VECTEUR a1b2, VECTEUR b1a2, VECTEUR a1b1,
                               VECTEUR u1, VECTEUR u2, double tolerance)
{
	VECTEUR n1 = utilitaire_normal(u1);
	VECTEUR n2 = utilitaire_normal(u2);
	double spn1a1b1 = utilitaire_produit_scalaire(n1, a1b1);
	double spn1a1b2 = utilitaire_produit_scalaire(n1, a1b2);
	double spn2b1a1 = utilitaire_produit_scalaire((VECTEUR){-(n2.x), -(n2.y)}, a1b1);
	double spn2b1a2 = utilitaire_produit_scalaire(n2, b1a2);
	
	if(fabs(spn1a1b1) < EPSIL_CONTACT || fabs(spn1a1b2) < tolerance
		|| spn1a1b1 * spn1a1b2 < 0)
	{ 
		if(fabs(spn2b1a1) < EPSIL_CONTACT || fabs(spn2b1a2) < tolerance
		   || spn2b1a1 * spn2b1a2 < 0) // 2 conditions pour intersection
			return 1;
	}
	return 0;
}

 VECTEUR utilitaire_normal(VECTEUR u)
{
	VECTEUR n = {-u.y, u.x};
	return n;
}



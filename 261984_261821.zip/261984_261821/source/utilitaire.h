#ifndef UTILITAIRE_H
#define UTILITAIRE_H

typedef struct vecteur VECTEUR;
struct vecteur
{
	double x;
	double y;
};

// fonctions de calcul des intersections
double points_trop_proche(double x1, double y1, double x2, double y2);
void parallelisme();
short utilitaire_superposition(double a1_x, double a1_y, double a2_x, 
							  double a2_y, double b1_x, double b1_y,
							  double b2_x, double b2_y, double tolerance);
short utilitaire_intersection(VECTEUR a1b2, VECTEUR b1a2, VECTEUR a1b1, 
							  VECTEUR u1, VECTEUR u2, double tolerance);
							  
//fonctions de calcul des différents vecteurs nécessaires pour les intersections
VECTEUR utilitaire_coor_vecteur(double x1, double y1, 
								double x2, double y2);
double utilitaire_norm(VECTEUR v);
VECTEUR utilitaire_unitaire(VECTEUR v, double norm);
double utilitaire_produit_vectoriel(VECTEUR v1, VECTEUR v2);
double utilitaire_produit_scalaire(VECTEUR v1, VECTEUR v2);
VECTEUR utilitaire_normal(VECTEUR u);
 
#endif

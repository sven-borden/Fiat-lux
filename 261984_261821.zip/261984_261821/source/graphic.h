#ifndef GRAPHIC_H
#define GRAPHIC_H

// fonctions de dessin
void graphic_draw_circle(double xc, double yc, float r);
void graphic_draw_segment(double x1, double y1, double x2, double y2);
void graphic_draw_rectangle(double deb_x, double deb_y, double fin_x, double fin_y);

// fonctions pour paramétrer l'épaisseur et la couleur des traits
void graphic_set_color3fv(const float color[3]);
void graphic_set_line_width(float width);

#endif

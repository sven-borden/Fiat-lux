// fichier: modele.c
// date: 08.04.2016
// description du module: automate de lecture du fichier donné en argument
//-------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "absorbeur.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "modele.h"
#include "photon.h"
#include "projecteur.h"
#include "reflecteur.h"
#include "utilitaire.h"
#define NB_LETTRES 9

static int nb_pr = 0, nb_r = 0, nb_a = 0, nb_ph = 0; 


// traite le fichier ligne par ligne.
int modele_lecture( char * nom_fichier)
{
	char tab[MAX_LINE];
	int erreur = 0;
	FILE * fichier = NULL;
	if((fichier = fopen (nom_fichier, "r")) != NULL) 
	{
		while(fgets(tab, MAX_LINE, fichier) != NULL)
		{
			// lignes à ignorer, on passe à la suivante
			if((tab[0]=='#')||(tab[0]=='\n')||(tab[0]=='\r')) continue; 
			erreur = modele_decodage_ligne(tab);
			if(erreur == 1)
			{
				fclose(fichier);
				return 1;
			}
		}
		if(strncmp(tab, "FIN_LISTE", NB_LETTRES) != 0)
		{
			error_fichier_incomplet();
			fclose(fichier);
			return 1;
		}
		fclose(fichier);
		//error_success(); seulement pour le rendu 1
		return 0;
	}
	else 
	{
		error_fichier_inexistant();
		return 1;
	}
}



// décodage selon l'etat courant d'une ligne lue dans le fichier 
// met à jour l'etat
int modele_decodage_ligne(char * tab)
{
	static int etat = PROJECTEUR; 
	int *ptr_nb_pr = &nb_pr, *ptr_nb_r = &nb_r;
	int *ptr_nb_a = &nb_a, *ptr_nb_ph = &nb_ph;
	static int i = 0, j = 0;
	int erreur = 0;
			
	switch(etat) 
	{
	case PROJECTEUR: 
		etat = modele_entite(tab, ptr_nb_pr, etat, i);
		i++;
		break;
	case REFLECTEUR: 
		etat = modele_entite(tab, ptr_nb_r, etat, i);
		i++;
		break;
	case ABSORBEUR:
		etat = modele_entite(tab, ptr_nb_a, etat, i);
		i++;
		break;
	case PHOTON:
		etat = modele_entite(tab, ptr_nb_ph, etat, i);
		i++;
		break;
	case FIN_LISTE:
		erreur = modele_fin_liste(&j, &i, &etat, tab);
		if(!erreur) return 0;
		else if(erreur == 1) return 1;
		break;
	case ERREUR:
		modele_remise_a_zero(&i, &j, &etat);
		return 1; 
	default: 
		error_fichier_incomplet();
		modele_remise_a_zero(&i, &j, &etat);
		return 1;
	}
	return 0;
} 

int modele_fin_liste(int *j, int *i, int *etat, char *tab)
{
	if(strncmp(tab, "FIN_LISTE", NB_LETTRES) == 0)
	{
		(*j)++;
		if(*j == 1) 
		{
			*etat = REFLECTEUR;
			*i = 0;
		}
		if(*j == 2) 
		{
			*etat = ABSORBEUR;
			*i = 0;
		}
		if(*j == 3) 
		{
			*etat = PHOTON;
			*i = 0;
		}
		if(*j == 4) 
		{
			modele_remise_a_zero(i, j, etat);
			return 0;
		}
	}
	else 
	{
		if(*j == 0) 
		{
			error_lecture_elements(ERR_PROJECTEUR, ERR_TROP); 
			modele_remise_a_zero(i, j, etat);
			return 1;
		}
		if(*j == 1)
		{
			 error_lecture_elements(ERR_REFLECTEUR, ERR_TROP);
			 modele_remise_a_zero(i, j, etat);
			 return 1;
		}
		if(*j == 2) 
		{
			error_lecture_elements(ERR_ABSORBEUR, ERR_TROP);
			modele_remise_a_zero(i, j, etat);
			return 1;
		}
		if(*j == 3) 
		{
			error_lecture_elements(ERR_PHOTON, ERR_TROP); 
			modele_remise_a_zero(i, j, etat);
			return 1;
		}
	}
	return FIN_LISTE;
}

int modele_entite(char * tab, int *ptr_nb, int etat, int i)
{
	int erreur = 0;
	switch(etat)
	{
		case PROJECTEUR:
			erreur = projecteur_decodage(tab, ptr_nb, i);
			break;
		case REFLECTEUR:
			erreur = reflecteur_decodage(tab, ptr_nb, i);
			break;
		case ABSORBEUR:
			erreur = absorbeur_decodage(tab, ptr_nb, i);
			break;
		case PHOTON:
			erreur = photon_decodage(tab, ptr_nb, i);
			break;
		default: return 1; 
	}
	if(erreur == 1) return ERREUR;
	else if((*ptr_nb == 0) || (i == *ptr_nb)) return FIN_LISTE;
	else return etat;
}

void modele_remise_a_zero(int *ptr_i, int *ptr_j, int *ptr_etat) 
{
	*ptr_etat = PROJECTEUR;
	*ptr_i = 0;
	*ptr_j = 0;
}

int modele_nb_pr()
{
	return nb_pr;
}

int modele_nb_r()
{
	return nb_r;
}

int modele_nb_a()
{
	return nb_a;
}

int modele_nb_ph()
{	
	return nb_ph;
}

void modele_modif_nb_element(int nb, int etat)
{
	switch(etat)
	{
		case PROJECTEUR:
			nb_pr = nb;
			break;
		case REFLECTEUR:
			nb_r = nb;
			break;
		case ABSORBEUR:
			nb_a = nb;
			break;
		case PHOTON:
			nb_ph = nb;
			break;
		default:
			// Unknown command
			break;
	}
}

void modele_nb_elem(int nb_elem[NB_ELEM2])
{
	nb_elem[PROJECTEUR] = modele_nb_pr();
	nb_elem[REFLECTEUR] = modele_nb_r();
	nb_elem[ABSORBEUR] = modele_nb_a();
	nb_elem[PHOTON] = modele_nb_ph();
}

void modele_listes_effacer()
{
	projecteur_vider_liste();
	reflecteur_vider_liste();
	/*absorbeur_vider_liste();
	absorbeur_vider_liste_2();*/
	photon_vider_liste();
	/*void reflecteur_liste_effacer();*/
	absorbeur_liste_effacer();
	absorbeur_liste_effacer_2();
	//void photon_liste_effacer();
}

void modele_affichage(short actif, double deb_x, double deb_y, 
					  double fin_x, double fin_y)
{
	const float noir[3] = {0., 0., 0.};
	
	projecteur_affichage();
	reflecteur_affichage();
	absorbeur_affichage();
	photon_affichage();
	
	if(actif)
	{
		graphic_set_line_width(3.);
		graphic_set_color3fv(noir);
		graphic_draw_rectangle(deb_x, deb_y, fin_x, fin_y);
	}
	
}

void modele_supp_hors_cadre(double x_max, double x_min, double y_max, 
							double y_min)
{
	photon_supprimer_hors_cadre(x_max, x_min, y_max, y_min);
}


void modele_suppr_selectionne(int etat)
{
	switch(etat)
	{
		case PROJECTEUR:
			projecteur_suppr_selectionne(nb_pr);
			break;
		case REFLECTEUR:
			reflecteur_suppr_selectionne(nb_r);
			break;
		case ABSORBEUR:
			absorbeur_suppr_selectionne(nb_a);
			break;
		default:
			printf("Unknown command\n");
			break;
	}
	printf("modele_suppr_selectionne is called.\n");
}


int modele_creation_elem(int etat, double mdeb_x, double mdeb_y, 
					      double mfin_x, double mfin_y)
{
	int erreur = 0;
	double alpha = 0;
		
	switch(etat)
	{
		case PROJECTEUR:
			//if(mdeb_x <= 0)
				//alpha = atan((mdeb_y - mfin_y)/(mdeb_x - mfin_x));
			//else 
				//alpha = atan((mdeb_y - mfin_y)/(mdeb_x - mfin_x)) + M_PI; 
			alpha = atan2(mfin_y - mdeb_y, mfin_x - mdeb_x);
			erreur = projecteur_creation(mdeb_x, mdeb_y, alpha);
			break;
		case REFLECTEUR:
			erreur = reflecteur_creation(mdeb_x, mdeb_y, mfin_x, mfin_y);
			break;
		default:
			// Unknown command
			break;
	}
	if(erreur == 0) return 1;
	else return 0;
}

int modele_creation_absorbeur(double deb_x, double deb_y, short *debcreation)
{
	int erreur = 0;
	erreur = absorbeur_creation(deb_x, deb_y, debcreation);
	if(erreur) return 0;
	else return 1;
}

int modele_pt_plus_proche(int live_entity, double x_pos, double y_pos)
{
	switch(live_entity)
	{
		case PROJECTEUR:
			projecteur_pt_plus_proche(x_pos, y_pos);
			break;
		case REFLECTEUR:
			reflecteur_pt_plus_proche(x_pos, y_pos);
			break;
		case ABSORBEUR:
			absorbeur_pt_plus_proche(x_pos, y_pos);
			break;
		default:
			// unknown
			return 0;
			break;
	}
	printf("modele_pt_plus_proche is called\n");
	return 1;
}

void modele_deselection(int etat)
{
	switch(etat)
	{
		case PROJECTEUR:
			reflecteur_deselection();
			absorbeur_deselection();
			break;
		case REFLECTEUR:
			projecteur_deselection();
			absorbeur_deselection();
			break;
		case ABSORBEUR:
			projecteur_deselection();
			reflecteur_deselection();
			break;
		case CREATION:
			projecteur_deselection();
			reflecteur_deselection();
			absorbeur_deselection();
		default:
			// Unknown command
			break;
	}
		
}


void modele_save (char * text_sortie)
{
	FILE *fichier;
	
	fichier = fopen(text_sortie, "w+"); //fichier dans lequel on sauvegarde 
	
	fprintf(fichier, "#Fichier de sauvegarde des états de FiatLux \n#\n\n");
	save_proj(fichier);
	save_refl(fichier);
	save_abs(fichier);
	save_phot(fichier);

	fclose(fichier);
}


void modele_sim_update()
{
	printf("sim_update\n");
}

void modele_one_step()
{
	printf("one step\n");
}

void modele_sim_elem_release()
{
	printf("sim_elem_release\n");
}

void modele_maj()
{
	photon_final_reflechi();
	projecteur_deselection();
	reflecteur_deselection();
	absorbeur_deselection();
}

void modele_creation_nveau_photon() 
{
	int i = 0, j = 0;
	double *proj_deb_x = 0, *proj_deb_y = 0;
	double xpos = 0, ypos = 0, alpha = 0;
	
	proj_deb_x = projecteur_renvoie_deb_x(i);
	proj_deb_y = projecteur_renvoie_deb_y(i);
	
	while(proj_deb_x && proj_deb_y)
	
	{
		xpos = *proj_deb_x;
		ypos = *proj_deb_y;
		alpha = projecteur_renvoie_alpha(i);
	
		for(j = 0; j < NBPH; j++)	
		{
			photon_creation(xpos, ypos, alpha);
			xpos -= EPSIL_PROJ*sin(alpha);  
			ypos += EPSIL_PROJ*cos(alpha);  
		}	
		i++;
		
		proj_deb_x = projecteur_renvoie_deb_x(i);
		proj_deb_y = projecteur_renvoie_deb_y(i);
	}
}

/**************************************************************/
int modele_verification_rendu2(void)
{
	double a1_x, a1_y,a2_x, a2_y; //absorbeurs
	double p1_x, p1_y, p2_x, p2_y; //projecteurs
	double r1_x, r1_y, r2_x, r2_y; //reflecteurs
	int i, j, k,l = 0, m = 0, n = 0;
	
	for(i = 0; i < nb_a;)
	{
		absorbeur_get_lineseg(&i, &l, &a1_x, &a1_y, &a2_x, &a2_y, 0); 
		for(j = 0; j < nb_r;)
		{
			reflecteur_get_lineseg(&j,&m, &r1_x, &r1_y, &r2_x, &r2_y);
			if(utilitaire_superposition(a1_x, a1_y, a2_x, a2_y, r1_x, r1_y, 
									   r2_x, r2_y, EPSIL_CONTACT))
			{
				error_lecture_intersection(ERR_ABSORBEUR,  l-1, 
										   ERR_REFLECTEUR, m-1);
				return 1;
			}
			for(k = 0; k < nb_pr;)
			{
				projecteur_get_lineseg(&k, &n, &p1_x, &p1_y, &p2_x, &p2_y);
				if(utilitaire_superposition(p1_x, p1_y, p2_x, p2_y, r1_x, r1_y,
				   r2_x, r2_y, EPSIL_CONTACT))
				{
					error_lecture_intersection(ERR_PROJECTEUR, n,
											   ERR_REFLECTEUR, m-1);
					return 1;
				}
				if(j == 1)
					if(utilitaire_superposition(p1_x, p1_y, p2_x, p2_y, a1_x,
											   a1_y, a2_x, a2_y, EPSIL_CONTACT)) 
					{
						error_lecture_intersection(ERR_ABSORBEUR,  l,
												   ERR_PROJECTEUR, n);

						return 1;
					}
			}
		}
	}
	if(reflecteur_verification(nb_r)) // return 0
		return 1;
	return 0;
}

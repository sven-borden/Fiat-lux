// fichier: graphic.c
// date: 16.04.2016
// description du module: fonctions liées à l'interface graphique
//-------------------------------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/glu.h>
#include <GL/glut.h>

#define SIDES 16

                        
void graphic_draw_circle(double xc, double yc, float r)
{ 
	int i;

	glBegin(GL_LINE_LOOP);
  
	for (i=0; i < SIDES; i++)
    {
		float alpha = i * 2. * M_PI / SIDES;
		
		glVertex2f(xc + r*cos(alpha), yc + r*sin(alpha));
    }
	glEnd();
}

void graphic_draw_segment(double x1, double y1, double x2, double y2) 
{ 
	glBegin(GL_LINES);

	glVertex2f(x1, y1);
	glVertex2f(x2, y2);

	glEnd();
}

void graphic_draw_rectangle(double deb_x, double deb_y, double fin_x, double fin_y)
{
	glBegin(GL_LINE_LOOP);
	
    glVertex2f(deb_x, deb_y);
    glVertex2f(fin_x, deb_y);
    glVertex2f(fin_x, fin_y);
    glVertex2f(deb_x, fin_y);

    glEnd();
}

void graphic_set_color3fv(const float color[3])
{
  glColor3fv(color);
}

void graphic_set_line_width(float width)
{
  glLineWidth(width);
}

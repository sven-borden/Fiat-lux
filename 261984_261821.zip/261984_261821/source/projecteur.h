#ifndef PROJECTEUR_H
#define PROJECTEUR_H

#include <stdio.h>
#include <stdlib.h>
#include "utilitaire.h"

typedef struct proj PROJ;

// fonction de décodage du fichier texte
int projecteur_decodage(char *tab, int *ptr_nb_pr, int i);

PROJ * projecteur_liste_ajouter();
void projecteur_liste_retirer(PROJ *e1);
void projecteur_vider_liste();

// fonctions de selection, de suppression et de création
double projecteur_pt_plus_proche(double x, double y);
int projecteur_deselection();
int projecteur_suppr_selectionne(int nb_pr);
int projecteur_supprimer(PROJ *a_supprimer, int nb_pr);
int projecteur_creation(double x, double y, double alpha);

// fonction d'affichage dans la fenêtre
void projecteur_affichage();

// fonctions de calcul ou qui renvoient des valeurs pour la mise à jour
void projecteur_coordonnees();
void projecteur_creation_vecteur(PROJ * courant);
double * projecteur_renvoie_deb_x(int i);
double * projecteur_renvoie_deb_y(int i);
double projecteur_renvoie_alpha(int i);
void projecteur_get_lineseg(int *i, int *n, double *p1_x, double *p1_y, 
							double *p2_x, double *p2_y);
int projecteur_verification_2(double deb_x, double deb_y, double fin_x, 
							  double fin_y, int etat, int i);
							  
// fonction qui sauvegarde l'état courant dans un fichier texte
void save_proj(FILE *fichier);

#endif

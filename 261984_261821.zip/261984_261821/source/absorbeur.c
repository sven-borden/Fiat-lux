// fichier: absorbeur.c
// date: 08.04.2016
// description du module: fonctions liées aux absorbeurs
//-------------------------------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "absorbeur.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "modele.h"
#include "photon.h"
#include "projecteur.h"
#include "reflecteur.h"
#include "utilitaire.h" 
#define NB_ABSO   1
#define MIN_PT    2
#define ERR_A	  3
#define FAUX      0
#define VRAI      1

struct abso{
	int nb_points; // numeros des points des segments d'absorbeur demarre a 0
	double deb_x;
	double deb_y;
	ABSO * suivant;
	double norme;
	double unit_x;
	double unit_y;
	double normal_x;
	double normal_y;
};

struct points{
	void * data;
	int nb_points; // nb de points par absorbeur
	int nb_element; // num de l'abso commence a 1 nb evolue
	short selection;
	POINTS * suivant;
};

static POINTS * p_tete = NULL;
static ABSO * nb_data = NULL;
static int nb_abso = 0;


int absorbeur_decodage(char *tab, int *ptr_nb_a, int i) 
{
	int erreur = 0, k = 0;
	static int l = 0;
	double a = 0, b = 0;
	char *p_start_a = NULL, *p_end_a = NULL;
	
	if(i == 0) {
		erreur = absorbeur_decodage_nb_a(tab, ptr_nb_a);
		return erreur;
	}
	
	POINTS * data = NULL;
	data = absorbeur_liste_ajouter();
	sscanf(tab,"%d", &data->nb_points);
	data->nb_element = i; 
	data->selection = FAUX;
	if((data->nb_points < MIN_PT)||(data->nb_points > MAX_PT)) {
		error_lect_nb_points_absorbeur();
		return 1;
	}
	else {
		p_start_a = tab+1;
		for(k = 0; k < (data->nb_points); k++) {
			nb_data = absorbeur_liste_ajouter_2(); 
			nb_data->nb_points = k;
			
			a = strtod(p_start_a, &p_end_a); 
			if(p_start_a == p_end_a){
				error_lecture_elements(ERR_ABSORBEUR, ERR_PAS_ASSEZ);
				return 1;
			}
			nb_data->deb_x = a; 
			p_start_a = p_end_a;
		

			b = strtod(p_start_a, &p_end_a);
			if(p_start_a == p_end_a){
				error_lecture_elements(ERR_ABSORBEUR, ERR_PAS_ASSEZ);
				return 1;
			}
			else nb_data->deb_y = b;
			p_start_a = p_end_a;
			
			if((l!=0)&&(l!=(*ptr_nb_a)*(data->nb_points))&&(nb_data->suivant)){
				if (points_trop_proche(nb_data->deb_x, nb_data->deb_y, 
					nb_data->suivant->deb_x, nb_data->suivant->deb_y) 
					<= EPSIL_CREATION){
					error_lecture_point_trop_proche(ERR_ABSORBEUR, i-1); 
					return 1;
				}
			}
			l++;
		}
		absorbeur_creation_vecteur();
		return 0;
	}
}

int absorbeur_decodage_nb_a(char *tab, int *ptr_nb_a)
{
	if(sscanf(tab,"%d", ptr_nb_a) != NB_ABSO) 
	{
		error_lect_nb_elements(ERR_ABSORBEUR); 
		return 1;
	}
	nb_abso = *ptr_nb_a;
	return 0;
}


POINTS * absorbeur_liste_ajouter()
{
	POINTS * e1 = NULL;
	if(!(e1 = malloc(sizeof(POINTS))))
	{
		printf("Pb d'allocation dans %s\n", __func__);
		exit(EXIT_FAILURE);
	}
	e1->suivant = p_tete;
	p_tete = e1;
	e1->data = NULL;
	return e1;
}

ABSO * absorbeur_liste_ajouter_2()
{
	ABSO * e1 = NULL;
	if(!(e1 = malloc(sizeof(ABSO))))
	{
		printf("Pb d'allocation dans %s\n", __func__);
		exit(EXIT_FAILURE);
	}
	e1->suivant = p_tete->data;
	p_tete->data = e1;
	return e1;
}

int absorbeur_creation(double deb_x, double deb_y, short *debcreation) 
{
	static int i = 1, j = 0;
	int nb_a = modele_nb_a();
	
	if(*debcreation == 1)
	{
		POINTS * data = NULL;
		data = absorbeur_liste_ajouter();
		data->nb_element = nb_abso + i; 
		data->selection = FAUX;
		*debcreation = 0;
		j = 0;
		i++;
		nb_a++;
		modele_modif_nb_element(nb_a, ABSORBEUR);
	}
	
	nb_data = absorbeur_liste_ajouter_2(); 
	nb_data->nb_points = j;
	nb_data->deb_x = deb_x;
	nb_data->deb_y = deb_y;
	j++; 
	
	if(j > 1)
	{
		if(reflecteur_verification_2(nb_data->deb_x, nb_data->deb_y, 
									 nb_data->suivant->deb_x, 
									 nb_data->suivant->deb_y, ABSORBEUR, 
									 p_tete->nb_element) ||
		   projecteur_verification_2(nb_data->deb_x, nb_data->deb_y, 
									 nb_data->suivant->deb_x, 
									 nb_data->suivant->deb_y, ABSORBEUR, 
									 p_tete->nb_element))
		{
			p_tete->selection = VRAI; 
			absorbeur_suppr_selectionne(nb_a);
			return 1;
		}
	}
	return 0;
}

/*void absorbeur_liste_retirer(ABSO *e1)
{
	ABSO * precedent = nb_data;
	ABSO * actuel = nb_data;
	
	while(actuel != e1 && actuel)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != nb_data)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			nb_data = actuel->suivant;
			free(actuel);
		}
	}
}

void absorbeur_vider_liste()
{
	// Retire un à un les elements en tete de la liste 
	ABSO *e1;
	while (p_tete)
	{
		e1 = nb_data;
		absorbeur_liste_retirer(e1);
	}
	nb_data = NULL;
}

void absorbeur_liste_retirer_2(POINTS *e1)
{
	POINTS * precedent = p_tete;
	POINTS * actuel = p_tete;
	
	while(actuel != e1 && actuel)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
}

void absorbeur_vider_liste_2()
{
	// Retire un à un les elements en tete de la liste  
	POINTS *e1;
	while (p_tete)
	{
		e1 = p_tete;
		absorbeur_liste_retirer_2(e1);
	}
	p_tete = NULL;
}*/

void absorbeur_liste_effacer()
{
	ABSO * precedent = nb_data;
	ABSO * actuel = nb_data;
	
	while(actuel && actuel->suivant)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != nb_data)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			nb_data = actuel->suivant;
			free(actuel);
		}
	}
	nb_data = NULL;
}

void absorbeur_liste_effacer_2()
{
	POINTS * precedent = p_tete;
	POINTS * actuel = p_tete;
	
	while(actuel && actuel->suivant)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
	p_tete = NULL;
}

double absorbeur_pt_plus_proche(double x, double y)
{
	absorbeur_deselection();
	// verifier si absorbeur
	if(!p_tete || !nb_data)
	{
		return 0; 
	}
	
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	POINTS * selectionne = NULL;
	
	double d1 = 0, d2 = 0;
	double d_min = sqrt(pow((x - actuel2->deb_x),2) + pow((y - actuel2->deb_y),2));
	
	while(actuel1)
	{
		while(actuel2 && actuel2->suivant)
		{
			d1 = sqrt(pow((x - actuel2->deb_x),2) + pow((y - actuel2->deb_y),2));
			d2 = sqrt(pow((x - actuel2->suivant->deb_x),2) + 
				 pow((y - actuel2->suivant->deb_x),2));
			if(d1 <= d_min)
			{
				d_min = d1;
				selectionne = actuel1;
			}
			if(d2 <= d_min)
			{
				d_min = d2;
				selectionne = actuel1;
			}
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
		if(actuel1)
			actuel2 = actuel1->data;
	}
	selectionne->selection = VRAI;
	
	return d_min;
}


int absorbeur_deselection()
{
	// verifier si absorbeurs
	if(!p_tete)
		return 0;
		
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	
	while(actuel1)
	{
		while(actuel2)
		{
			if(actuel1->selection == VRAI)
			{
				actuel1->selection = FAUX;
			}
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
		if(actuel1)
			actuel2 = actuel1->data;
	}
	
	return 0;
}


int absorbeur_suppr_selectionne(int nb_a) 
{
	// verifie si absorbeur
	if(!p_tete || !nb_data)
		return 0;
		
	POINTS * actuel1 = p_tete;
	
	while(actuel1)
	{
		if(actuel1->selection)
		{
			absorbeur_supprimer(actuel1->nb_element, nb_a);
			break;
		}
		actuel1 = actuel1->suivant;
	}
	return 0;
}

int absorbeur_supprimer(int id, int nb_a)
{
	POINTS *absorbeur = p_tete;
	
	if(!p_tete)
		return 1;
		
	// cas où l'absorbeur est le premier element
	if(p_tete->nb_element == id)
	{
		p_tete = p_tete->suivant;
		free(absorbeur);
		nb_a--;
		modele_modif_nb_element(nb_a, ABSORBEUR);
		return 1;
	}
	
	POINTS *precedent = absorbeur;
	
	while(precedent->suivant && precedent->suivant->nb_element != id)
		precedent = precedent->suivant;
		
	if(precedent->suivant)
	{
		POINTS * supprimer = precedent->suivant;
		precedent->suivant = precedent->suivant->suivant;
		free(supprimer);
		supprimer = NULL;
		nb_a--;
		modele_modif_nb_element(nb_a, ABSORBEUR);
		return 1;
	}
	return 0;
}

int absorbeur_intersection_photon(double deb_x, double deb_y, 
								  double fin_x, double fin_y) 
{
	if(!p_tete || !nb_data) // verifier si absorbeur
		return 0;
	
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	
	while(actuel1)
	{
		while(actuel2 && actuel2->suivant)
		{
			if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel2->deb_x, 
									   actuel2->deb_y, actuel2->suivant->deb_x, 
									   actuel2->suivant->deb_y, EPSIL_CONTACT)) 
			{
				return 1;
			}
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
		if(actuel1)
			actuel2 = actuel1->data;
	}
	
	return 0;
}


void absorbeur_creation_vecteur () 
{
	ABSO * courant = nb_data;
    double vect_x = 0, vect_y = 0; 
   
	while(courant->suivant)
	{
		vect_x = courant->suivant->deb_x - courant->deb_x;
		vect_y = courant->suivant->deb_y - courant->deb_y;
		
		courant->norme = sqrt (pow (vect_x, 2) + pow (vect_y, 2));
    
		//vecteur unitaire 
		courant->unit_x = vect_x / courant->norme;
		courant->unit_y = vect_y / courant->norme;
    
		//vecteur normal
		courant->normal_x = - courant->unit_y;
		courant->normal_y = courant->unit_x;
		
		courant = courant->suivant;
	}
}


void absorbeur_affichage() 
{
	const float bleu[3] = {0., 0., 1.};
	graphic_set_color3fv(bleu);
	
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	
	while(actuel1)
	{
		while(actuel2->suivant)
		{
			if(actuel1->selection == VRAI)
			{
				graphic_set_line_width(4.);
			}
			else
			{
				graphic_set_line_width(2.);
			}
			graphic_draw_segment(actuel2->deb_x, actuel2->deb_y, 
								 actuel2->suivant->deb_x, 
								 actuel2->suivant->deb_y);
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
		if(actuel1)
		{
			actuel2 = actuel1->data;
		}
	}
}


/**************************************************************/
void absorbeur_get_lineseg(int *i, int *l, double *a1_x, double *a1_y, double *a2_x,
						   double *a2_y, short set_back)
{		
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	static int j = 0; 
	if(set_back) // quand un nouveau fichier est load
		j = 1;
	else
	{
		while(actuel1 && (actuel1->nb_element > *i) ) //commence a 1
		{
			while(actuel2 && actuel2->suivant && (actuel2->nb_points >= j)) 
			{
				*a1_x = actuel2->deb_x;
				*a1_y = actuel2->deb_y;
				*a2_x = actuel2->suivant->deb_x; // valeur d'avant
				*a2_y = actuel2->suivant->deb_y; // idem
				actuel2 = actuel2->suivant;
				j++;
			}
			actuel1 = actuel1->suivant;
			if(actuel1) 
			{
				actuel2 = actuel1->data;
				*l = actuel1->nb_element;
			}
		
			j = 0; 
		}
		(*i)++; 
	}
}

int absorbeur_verification_2(double deb_x, double deb_y, double fin_x, 
							 double fin_y, int etat, int i)
{
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	
	while(actuel1)
	{
		while(actuel2 && actuel2->suivant)
		{
			if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel2->deb_x,
									   actuel2->deb_y, actuel2->suivant->deb_x, 
									   actuel2->suivant->deb_y, EPSIL_CONTACT))
			{
				error_lecture_intersection(etat, i-1, ERR_ABSORBEUR, 
										   actuel1->nb_element-1);
				return 1;  
			}
		}
	}
	return 0;
}

int absorbeur_verification_3(double deb_x, double deb_y, double fin_x, 
							 double fin_y, int etat, int i, double *d_a)
{
	POINTS * actuel1 = p_tete;
	ABSO * actuel2 = nb_data;
	double d2 = 0, x2 = 0, y2 = 0;
	int intersection = 0;
	
	while(actuel1)
	{
		while(actuel2 && actuel2->suivant)
		{
			if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel2->deb_x,
									   actuel2->deb_y, actuel2->suivant->deb_x, 
									   actuel2->suivant->deb_y, EPSIL_CONTACT))
			{
				photon_intersection(deb_x, deb_y, fin_x, fin_y, actuel2->deb_x,
								     actuel2->deb_y, actuel2->suivant->deb_x, 
								     actuel2->suivant->deb_y, &x2, &y2);
				d2 = photon_distance_reflecteur(x2, y2, deb_x, deb_y);
				if (d2 < *d_a)
				{
					*d_a = d2;
				}
				intersection++;
			}
			actuel2 = actuel2->suivant;
		}
		actuel1 = actuel1->suivant;
		if(actuel1)
			actuel2 = actuel1->data;
	}
	if(intersection) return 1;
	return 0;
}

void save_abs(FILE * fichier) 
{
	POINTS * actuel = p_tete;
	ABSO * actuel2 = nb_data;
	
	fprintf(fichier, "#absorbeurs\n");
	if(actuel)
	{
		fprintf (fichier, "%d\n", actuel->nb_element);
	}
	while(actuel)
	{
		fprintf(fichier, "%d ", actuel->nb_points);
		while(actuel2)
		{
			fprintf(fichier, "%f %f ", actuel2->deb_x, actuel2->deb_y);
			actuel2 = actuel2->suivant;
		}
		actuel = actuel->suivant;
		if(actuel)
		{
			actuel2 = actuel->data;
		}
		fprintf (fichier, "\n");
	}
	fprintf(fichier, "FIN_LISTE\n\n");
}

#ifndef ABSORBEUR_H
#define ABSORBEUR_H

#include <stdio.h>
#include <stdlib.h>

typedef struct abso ABSO;
typedef struct points POINTS;

// fonctions de décodage du fichier texte
int absorbeur_decodage(char *tab, int *ptr_nb_a, int i);
int absorbeur_decodage_nb_a(char *tab, int *ptr_nb_a);

POINTS * absorbeur_liste_ajouter();
ABSO * absorbeur_liste_ajouter_2();
/*void absorbeur_liste_retirer(ABSO *e1);
void absorbeur_liste_retirer_2(POINTS *e1);
void absorbeur_vider_liste();
void absorbeur_vider_liste_2();*/
void absorbeur_liste_effacer();
void absorbeur_liste_effacer_2();

// fonctions de sélection, de suppression et de création
int absorbeur_creation(double deb_x, double deb_y, short *debcreation);
double absorbeur_pt_plus_proche(double x, double y);
int absorbeur_deselection();
int absorbeur_suppr_selectionne(int nb_a);
int absorbeur_supprimer(int id, int nb_a);

// fonctions de calcul d'intersections avec les différentes entités
int absorbeur_intersection_photon(double sdeb_x, double sdeb_y, 
								  double sfin_x, double sfin_y);
int absorbeur_verification_2(double deb_x, double deb_y, double fin_x, 
						     double fin_y, int etat, int i);
int absorbeur_verification_3(double deb_x, double deb_y, double fin_x, 
							 double fin_y, int etat, int i, double *d_a);
								  
// fonction d'affichage dans la fenêtre
void absorbeur_affichage();

// fonction de calcul ou qui renvoient des valeurs pour la mise à jour
void absorbeur_creation_vecteur();
void absorbeur_affichage_2(double **tab);
void absorbeur_get_lineseg(int *i, int *l, double *a1_x, double *a1_y, double *a2_x,
						   double *a2_y, short set_back);
						   
// fonction de sauvegarde dans un fichier texte
void save_abs(FILE * fichier);

#endif

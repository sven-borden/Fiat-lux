// sciper1: 261984
// nom1: Demeure
// prenom1: Eugénie
// sciper2: 261821
// nom2: Jullien
// prenom2: Sorya
// fichier: main.cpp
// date: 20.03.2016
// description du programme: projet PROG II Printemps 2015-16 EPFL MT-EL
//-------------------------------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <GL/glui.h>

extern "C" {
	#include "modele.h"
	#include "constantes.h"
}

#define LOAD_ID 			11
#define SAVE_ID 			12
#define START_ID 			13
#define STEP_ID 			14
#define EXIT_ID 			15
#define LOADTEXT_ID 		16
#define SAVETEXT_ID 		17
#define ACTION_ID 			18
#define ENTITY_ID 			19
#define WSIZE_X				400
#define WSIZE_Y				400
#define POS_GLUI_X 			750
#define POS_GLUI_Y 			200
#define POS_GLUT_X 			150
#define POS_GLUT_Y			150
#define VRAI 				1
#define FAUX 				0
#define MAX_CHAR            100


namespace {
	GLUI_Button		*load;
	GLUI_Button		*save;
	GLUI_Button		*start;
	GLUI_Button		*step;
	GLUI_EditText   *loadtext;
	GLUI_EditText   *savetext;	
	GLUI_EditText   *nb_photons;	  
	GLUI_EditText   *nb_projecteurs;	
	GLUI_EditText   *nb_absorbeurs;	  
	GLUI_EditText   *nb_reflecteurs;
	GLUI_RadioGroup *action_group;
	GLUI_RadioGroup *entity_group;

	GLfloat x_min = -DMAX;
	GLfloat x_max = DMAX;
	GLfloat y_min = -DMAX;
	GLfloat y_max = DMAX;
	
	double mdeb_x = 0;
	double mdeb_y = 0;
	double mfin_x = 0;
	double mfin_y = 0;
	
	double x_dmax = 0;
	double y_dmax = 0;
	
	int width;
	int height;
	int main_window;
	
	short rendu_final = VRAI;
	short actif = FAUX;
	short stop = FAUX; // si stop == 1 alors la simulation est en start
	short maj = FAUX;
	short creation = FAUX;
	short debcreation = VRAI;
	
	int nb_points = 0;
	
	char text_entree[MAX_CHAR]; 
	char text_sortie[MAX_CHAR] = "save.txt"; 
	int live_action, live_entity;
	int element;
	
	int nb_elem[NB_ELEM2] = {0};
}

int argument_terminal(int argc, char * argv[]);
void fenetre_glui(void);
void initialisation();
void initialiser();
void nb_elem_maj();
void mouse_cb(int button, int state, int x, int y);
void mouse_creation(int button, int state, int x, int y);
void process_mouse_cb(int x, int y);
void click_position(int x, int y, double *xpos, double *ypos);
void keyboard_cb(unsigned char key, int x, int y);
void zoom(void);
void idle_cb();
void control_cb(int control);
void reshape_cb(int x, int y);
void display_cb();


// lit le fichier dont le nom est transmis sur la ligne de commande
int main(int argc, char * argv[])         
{
	int erreur = 0;
	
	erreur = argument_terminal(argc, argv);
	if(erreur) return EXIT_SUCCESS;
	/*
	if(argc >= 3) 
	{
		if(strcmp(argv[1], "Error") == 0) 
		{
			erreur = modele_lecture(argv[2]);
			rendu_final = FAUX;
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1; 
			}
		}
		if(strcmp(argv[1], "Verification") == 0)
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			rendu_final = FAUX;
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		if(strcmp(argv[1], "Graphic") == 0) 
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			rendu_final = FAUX; 
			//quand on appuie sur start ne lance pas la simulation
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		if(strcmp(argv[1], "Final") == 0) 
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			rendu_final = VRAI; 
			//quand on appuie sur start lance la simulation
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		else
		{
			printf("erreur : usage : '././rendu3.x mode_test nom_fichier' "
			       "ou '././rendu3.x'\n");
			return 1;
		}
	}
	if(argc == 2)
	{
		printf("erreur : usage : '././rendu3.x mode_test nom_fichier' "
			   "ou '././rendu3.x'\n");
		return 1;
	}*/

	glutInit(&argc, argv);		
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);	
	glutInitWindowSize(WSIZE_X, WSIZE_Y);
	glutInitWindowPosition(POS_GLUT_X, POS_GLUT_Y);
	main_window = glutCreateWindow("Fiat Lux !");
		
	glutDisplayFunc(display_cb);
	glutReshapeFunc(reshape_cb);			
	glutMouseFunc(mouse_cb);
	glutMotionFunc(process_mouse_cb);
	glutKeyboardFunc(keyboard_cb);
	width = WSIZE_X;
	height = WSIZE_Y;
	keyboard_cb('r', 0, 0); //réinitialise le zoom
	
	GLUI_Master.set_glutIdleFunc(idle_cb);
			
	fenetre_glui();
	initialisation();
	
	// depuis la ligne de commande
	if(argc == 3)
	{
		loadtext->set_text(argv[2]);
		glutSetWindow(main_window);
		modele_listes_effacer(); 
		modele_lecture(text_entree); 
		display_cb();
	}
   
	glutMainLoop();
	return EXIT_SUCCESS;
}

int argument_terminal(int argc, char * argv[])
{
	int erreur = 0;
	if(argc >= 3) 
	{
		if(strcmp(argv[1], "Error") == 0) 
		{
			erreur = modele_lecture(argv[2]);
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1; 
			}
		}
		if(strcmp(argv[1], "Verification") == 0)
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		if(strcmp(argv[1], "Graphic") == 0) 
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			rendu_final = FAUX; 
			//quand on appuie sur start ne lance pas la simulation
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		if(strcmp(argv[1], "Final") == 0) 
		{
			erreur += modele_lecture(argv[2]);
			erreur += modele_verification_rendu2();
			rendu_final = VRAI; 
			//quand on appuie sur start lance la simulation
			if(erreur)
			{
				modele_listes_effacer(); 
				return 1;
			}
		}
		else
		{
			printf("erreur : usage : '././rendu3.x mode_test nom_fichier' "
			       "ou '././rendu3.x'\n");
			return 1;
		}
	}
	if(argc == 2)
	{
		printf("erreur : usage : '././rendu3.x mode_test nom_fichier' "
			   "ou '././rendu3.x'\n");
		return 1;
	}
	return 0;
}

void fenetre_glui(void) 
{
 	GLUI *glui = GLUI_Master.create_glui((char*) "Fiat Lux !", 0, 
											POS_GLUI_X, POS_GLUI_Y);
 	
	//file
	GLUI_Panel*file_panel = glui->add_panel("File", GLUI_PANEL_EMBOSSED);
  
	loadtext =glui->add_edittext_to_panel (file_panel, "FileName", 
										   GLUI_EDITTEXT_TEXT, text_entree, 
										   LOADTEXT_ID, control_cb); 
	load = glui->add_button_to_panel (file_panel, "Load", LOAD_ID, control_cb); 
	savetext =glui->add_edittext_to_panel (file_panel, "FileName", 
										   GLUI_EDITTEXT_TEXT, text_sortie, 
										   SAVETEXT_ID, control_cb); 
	save = glui->add_button_to_panel (file_panel, "Save", SAVE_ID, control_cb);
    
	//Simulation
	GLUI_Panel*simul_panel = glui->add_panel("Simulation", GLUI_PANEL_EMBOSSED);
	start = glui->add_button_to_panel (simul_panel,"Start !", START_ID, control_cb); 
	step = glui->add_button_to_panel (simul_panel,"Step", STEP_ID, control_cb);
  
	//exit
	glui->add_button("Exit", 0, (GLUI_Update_CB)exit);
	
	//ajouter une colonne
	glui->add_column(true);
   
	//information
	GLUI_Panel*info_panel = glui->add_panel("Information", GLUI_PANEL_EMBOSSED);
	nb_photons = glui->add_edittext_to_panel (info_panel, "Nb Photons"); 
	nb_projecteurs = glui->add_edittext_to_panel (info_panel, "Nb Projecteurs"); 
	nb_absorbeurs = glui->add_edittext_to_panel (info_panel, "Nb Absorbeurs"); 
	nb_reflecteurs = glui->add_edittext_to_panel (info_panel, "Nb Reflecteurs");

  
	//mouse panel
	GLUI_Panel*mouse_panel = glui->add_panel("Mouse panel", GLUI_PANEL_EMBOSSED);

	GLUI_Panel*action_panel = glui->add_panel_to_panel(mouse_panel,
													   "Action selection", 
													   GLUI_PANEL_EMBOSSED);
	action_group = glui->add_radiogroup_to_panel (action_panel, &live_action, 
												  ACTION_ID, control_cb); 
	glui->add_radiobutton_to_group (action_group, "Selection"); 
	glui->add_radiobutton_to_group (action_group, "Creation");

	GLUI_Panel*entity_panel = glui->add_panel_to_panel(mouse_panel, 
													   "Entity selection", 
													   GLUI_PANEL_EMBOSSED); 
	entity_group = glui->add_radiogroup_to_panel (entity_panel, &live_entity, 
												  ENTITY_ID, control_cb); 
	glui->add_radiobutton_to_group (entity_group, "Projecteur");
	glui->add_radiobutton_to_group (entity_group, "Reflecteur");
	glui->add_radiobutton_to_group (entity_group, "Absorbeur");
}

void initialisation()
{
	loadtext->set_text("test.txt");
	savetext->set_text("save.txt");
	nb_elem_maj();
	initialiser();
}

void initialiser()
{
	live_action = 0;
	action_group->set_int_val(live_action);
	live_entity = 0;
	entity_group->set_int_val(live_entity);
	debcreation = VRAI;
	creation = FAUX;
	nb_points = 0;
}

void nb_elem_maj()
{
	modele_nb_elem(nb_elem);
	nb_photons->set_int_val(nb_elem[PHOTON]);
	nb_projecteurs->set_int_val(nb_elem[PROJECTEUR]);
	nb_absorbeurs->set_int_val(nb_elem[ABSORBEUR]);
	nb_reflecteurs->set_int_val(nb_elem[REFLECTEUR]);
}

void mouse_cb(int button, int state, int x, int y) 
{ 
	if(button == GLUT_LEFT_BUTTON)
	{
		if(state == GLUT_DOWN)	//if down: sauvegarde la position de base
		{
			actif = 1;
		    click_position(x, y, &mdeb_x, &mdeb_y);
		}
		else  //if up: zoom
		{
			actif = 0;
			click_position(x, y, &mfin_x, &mfin_y);
			if(sqrt(pow((mdeb_x - mfin_x), 2)
			   + pow((mdeb_y - mfin_y),2)) > EPSIL_CREATION)
			{
				zoom();
			}
		}
	}
	else if(button == GLUT_RIGHT_BUTTON && rendu_final && !stop && !actif) 
	{ 
		double x_pos, y_pos;
		if(state == GLUT_DOWN && !creation)
		{
			if(!live_action) // l'utilisateur clique sur selection
			{
				click_position(x, y, &x_pos, &y_pos);
				modele_pt_plus_proche(live_entity, x_pos, y_pos);
			}
			else            // l'utilisateur clique sur creation
			{ 
				creation = 1; 
				click_position(x, y, &mdeb_x, &mdeb_y);
				if(live_action && live_entity == 2 && nb_points < MAX_PT)
				{
					live_action = modele_creation_absorbeur(mdeb_x, mdeb_y, 
															&debcreation);
					if(live_action) nb_points++;
					else initialiser();
				}
				else if(nb_points >= MAX_PT)
				{
					printf("limite de points d'un absorbeur atteinte (main.cpp)\n");
					initialiser();
				}
			}
		}
		else if(state == GLUT_DOWN && creation && live_action) 
			mouse_creation(button, state, x, y);
	}
	glutPostRedisplay();
}

void mouse_creation(int button, int state, int x, int y)
{
	if(live_entity != 2)   
	{
		creation = 0; 
		click_position(x, y, &mfin_x, &mfin_y);
				
		if(sqrt(pow((mdeb_x - mfin_x), 2)
		   + pow((mdeb_y - mfin_y), 2)) > EPSIL_CREATION)
		{
			live_action = modele_creation_elem(live_entity, mdeb_x, 
											   mdeb_y, mfin_x, mfin_y);
			if(!live_action) initialiser();
		}
		else 
		{
			printf("pts de création trop proches (main.cpp)\n");
			initialiser();
		}
	}
	else if(live_entity == 2) 
	{
		creation = 0;  
		click_position(x, y, &mfin_x, &mfin_y);
			
		if(sqrt(pow((mdeb_x - mfin_x), 2)
		   + pow((mdeb_y - mfin_y), 2)) > EPSIL_CREATION)
		{
			if(live_action && live_entity == 2 && nb_points < MAX_PT)
			{
				live_action = modele_creation_absorbeur(mfin_x, mfin_y, 
														&debcreation);
				if(live_action) nb_points++;
				else initialiser();
			}
			else if(nb_points >= MAX_PT)
			{ 	
				printf("limite de points d'un absorbeur atteinte (main.cpp)\n");
				initialiser();
			}
		}
		else 
		{
			printf("pts de création trop proches (main.cpp)\n");
			initialiser();
		}
	}
}

/*void mouse_cb(int button, int state, int x, int y) 
{ 
	if(button == GLUT_LEFT_BUTTON)
	{
		if(state == GLUT_DOWN)	//if down: sauvegarde la position de base
		{
			actif = 1;
		    click_position(x, y, &mdeb_x, &mdeb_y);
		}
		else  //if up: zoom
		{
			actif = 0;
			click_position(x, y, &mfin_x, &mfin_y);
			if(sqrt(pow((mdeb_x - mfin_x), 2)
			   + pow((mdeb_y - mfin_y),2)) > EPSIL_CREATION)
			{
				zoom();
			}
		}
	}
	else if(button == GLUT_RIGHT_BUTTON && rendu_final) 
	{ 
		double x_pos, y_pos;
		if(state == GLUT_DOWN && !actif && !creation)
		{
			if(!live_action && !stop) // l'utilisateur clique sur selection
			{
				click_position(x, y, &x_pos, &y_pos);
				modele_pt_plus_proche(live_entity, x_pos, y_pos);
			}
			else if(live_action && !stop) // l'utilisateur clique sur creation
			{ 
				creation = 1; 
				click_position(x, y, &mdeb_x, &mdeb_y);
				if(live_action && live_entity == 2 && nb_points < MAX_PT)
				{
					live_action = modele_creation_absorbeur(mdeb_x, mdeb_y, 
															&debcreation);
					if(live_action) nb_points++;
					else initialiser();
				}
				else if(nb_points >= MAX_PT)
				{
					printf("limite de points d'un absorbeur atteinte (main.cpp)\n");
					initialiser();
				}
			}
		}
		else if(state == GLUT_DOWN && !actif && creation && !stop && 
				live_entity != 2 && live_action)   
		{
			creation = 0; 
			click_position(x, y, &mfin_x, &mfin_y);
			
			if(sqrt(pow((mdeb_x - mfin_x), 2)
			   + pow((mdeb_y - mfin_y), 2)) > EPSIL_CREATION)
			{
				live_action = modele_creation_elem(live_entity, mdeb_x, 
												   mdeb_y, mfin_x, mfin_y);
				if(!live_action) initialiser();
			}
			else 
			{
				printf("pts de création trop proches (main.cpp)\n");
				initialiser();
			}
		}
		else if(state == GLUT_DOWN && !actif && creation && !stop && 
				live_entity == 2 && live_action) 
		{
			creation = 0;  
			click_position(x, y, &mfin_x, &mfin_y);
				
			if(sqrt(pow((mdeb_x - mfin_x), 2)
			   + pow((mdeb_y - mfin_y), 2)) > EPSIL_CREATION)
			{
				if(live_action && live_entity == 2 && nb_points < MAX_PT)
				{printf("connard\n");
					live_action = modele_creation_absorbeur(mfin_x, mfin_y, 
															&debcreation);
					if(live_action) nb_points++;
					else initialiser();
					printf("connard2\n");
				}
				else if(nb_points >= MAX_PT)
				{ 	
					printf("limite de points d'un absorbeur atteinte (main.cpp)\n");
					initialiser();
				}
			}
			else 
			{
				printf("pts de création trop proches (main.cpp)\n");
				initialiser();
			}
		}
	}
	glutPostRedisplay();
}*/

void process_mouse_cb(int x, int y)
{
	click_position(x, y, &mfin_x, &mfin_y);
	glutPostRedisplay();
}


void click_position(int x, int y, double *xpos, double *ypos)
{
	mfin_x = x_min + (x_max - x_min) * (double)x / width;
	mfin_y = y_max - (y_max - y_min) * (double)y / height;
	if(xpos != NULL && ypos != NULL)
	{
		*xpos = mfin_x;
		*ypos = mfin_y;
	}
}


void keyboard_cb(unsigned char key, int x, int y)
{
	switch(key)
	{
		case 'r':
			x_min = y_min = -DMAX;
			x_max = y_max = DMAX;
			x_dmax = y_dmax = DMAX; 
			reshape_cb(width, height);
			break;
		case 'k': 
			if(rendu_final) 
				modele_supp_hors_cadre(x_max, x_min, y_max, y_min);
			break;
		case 'd':
			if(!stop && rendu_final)
			{
				printf("delete element selectionne\n");
				modele_suppr_selectionne(live_entity);
			}
			break;
	}
	glutPostRedisplay();
}


void zoom(void) 
{
	double x = fabs(mfin_x - mdeb_x);
	double y = fabs(mfin_y - mdeb_y);
	double zoom_x = x / (x_max - x_min); // pourcentage du zoom
	double zoom_y = y / (y_max - y_min);
	double add_x = 0, add_y = 0;
	
	x_dmax = x / 2;
	y_dmax = y / 2;
	
	if(zoom_x > zoom_y) 
		add_y = (y - zoom_x * (y_max - y_min)) / -2;
	else
		add_x = (x - zoom_y * (x_max - x_min)) / -2;

	if(mdeb_x < mfin_x) //ajustement du champ de vision
	{
		x_min = mdeb_x - add_x;
		x_max = mfin_x + add_x;
	}
	else
	{
		x_max = mdeb_x + add_x;
		x_min = mfin_x - add_x;
	}
	if(mdeb_y < mfin_y)
	{
		y_min = mdeb_y - add_y;
		y_max = mfin_y + add_y;
	}
	else
	{
		y_max = mdeb_y + add_y;
		y_min = mfin_y - add_y;
	}
}

void idle_cb()
{
	if(glutGetWindow() != main_window)
		glutSetWindow(main_window);
	glutPostRedisplay();
	
	if(stop)
	{
		if(maj && rendu_final)
		{
			modele_creation_nveau_photon();
			modele_maj();
			nb_elem_maj(); //mise à jour des boîtes de texte
			glutPostRedisplay();
		}
		else if(!rendu_final)
		{
			modele_sim_update();
		}
	}
}

void control_cb(int control)
{
    switch(control) 
    {
		case (LOAD_ID): 
			glutSetWindow(main_window);
			modele_listes_effacer(); 
			modele_lecture(text_entree); 
			keyboard_cb('r', 0, 0);
			nb_elem_maj();
			initialiser();
			display_cb();
			break;
		case (SAVE_ID):
			initialiser();
			modele_save(text_sortie);
			break;
		case (START_ID):
			if(stop)
			{
				stop = FAUX;
				maj = FAUX;
				start->set_name("Start !");
				break;
			}
			if(!stop)
			{
				start->set_name("Stop");
				initialiser();
				stop = VRAI;
				maj = VRAI;
				glutPostRedisplay();
				break;
			}
			else break;
		case (STEP_ID):
			if(!stop && rendu_final)
			{
				initialiser();
				modele_creation_nveau_photon();
				nb_elem_maj();
				modele_maj();
			}
			else if(!stop && !rendu_final)
			{
				modele_one_step();
			}
			break;
		case (ACTION_ID): 
			if(!stop)   
			{
				if(live_action == 0) // l'utilisateur appuie sur selection
				{
					printf("selection d'un element\n");
					debcreation = VRAI;
					creation = FAUX;
					nb_points = 0;
				}
				else //l'utilisateur appuie sur création
				{
					printf("creation d'un element\n");
				}
			}
			break;
		case (ENTITY_ID): 
			if(!rendu_final) modele_sim_elem_release();
			if(live_entity != 2) 
			{
				debcreation = VRAI;
				creation = FAUX;
				nb_points = 0;
			}
			break;
		default:
			//unknown command
			break;
		
	}
}

void reshape_cb(int x, int y)
{
	double ajout;
	glViewport(0, 0, x, y);
	
	width = x;
	if(y != 0) height = y;
	else height = 1;

	// ajustement du domaine visualisé selon la forme de la fenêtre 
	float aspect_ratio = (float) width / height ;
	
	if(aspect_ratio <= x_dmax/y_dmax)
	{		//"ajout" pour garder les proportions
		ajout = ((x_max - x_min) / 2 - x_dmax); 
		x_min += ajout;					    
		x_max -= ajout;						
		ajout = x_dmax / aspect_ratio - (y_max - y_min) / 2;
		y_min -= ajout;
		y_max += ajout;
	}
	else
	{	    //"ajout" pour garder les proportions
		ajout = ((y_max - y_min) / 2 - y_dmax); 
		y_min += ajout;
		y_max -= ajout;
		ajout = y_dmax * aspect_ratio - (x_max - x_min) / 2;
		x_min -= ajout;
		x_max += ajout;
	}
}

void display_cb () // s'occupe uniquement de l'affichage de la fenetre pas du panel
{	
	glClearColor ( 1., 1., 1., 0. ); 
	glClear(GL_COLOR_BUFFER_BIT);
	
	// ré-initialisation de la matrice de transformation 
	glLoadIdentity();
	
	glOrtho(x_min, x_max, y_min, y_max, -1.0, 1.0); 
	
	if(live_action) modele_deselection(CREATION);
	else modele_deselection(live_entity);
	nb_elem_maj();
	modele_affichage(actif, mdeb_x, mdeb_y, mfin_x, mfin_y); 
	
	glutSwapBuffers();
}

#ifndef PHOTON_H
#define PHOTON_H

#include <stdio.h>
#include <stdlib.h>
#include "utilitaire.h"

typedef struct phot PHOT;

// fonction pour lire le fichier texte
int photon_decodage(char *tab, int *ptr_nb_ph, int i);

PHOT * photon_liste_ajouter();

// fonctions liées à la simulation
void photon_creation(double x, double y, double alpha);
void photon_final_reflechi();

// fonction d'affichage dans la fenêtre
void photon_affichage();

// fonctions de suppression
//void photon_liste_effacer();
void photon_liste_retirer(PHOT *e1);
void photon_vider_liste();
void photon_supprimer_hors_cadre(double x_max, double x_min, double y_max, 
							     double y_min);
void photon_supprimer(int id);

// fonction pour sauvegarder la simulation dans un fichier texte
void save_phot(FILE * fichier);

// fonctions de calculs pour la mise à jour
void photon_coordonnees ();
double determinant(double x1, double y1, double x2, double y2);
void photon_intersection (double deb_x, double deb_y, double fin_x, 
						  double fin_y, double r1_x, double r1_y, double r2_x, 
						  double r2_y, double *x, double *y);
double photon_distance_reflecteur(double x, double y, double ph_x, double ph_y);
VECTEUR photon_suivant_coor(double l1, double x1, double y1, VECTEUR w, double L);
void photon_angle(PHOT **actuel, double x1, double y1, double x2, double y2);

// fonction de vérification des intersections
void photon_test_reflecteur (PHOT **actuel, double r1_x,
							 double r1_y, double r2_x, double r2_y,double L);

#endif

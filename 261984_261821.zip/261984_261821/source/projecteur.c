// fichier: projecteur.c
// date: 08.04.2016
// description du module: fonctions liées aux projecteurs
//-------------------------------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "absorbeur.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "modele.h"
#include "reflecteur.h"
#include "projecteur.h"
#include "utilitaire.h" 
#define NB_ELEM    3 
#define NB_PROJ    1
#define ERR 	   4
#define ERR_PR 	   1
#define FAUX	   0
#define VRAI 	   1

struct proj{
	double deb_x;
	double deb_y;
	double alpha;
	int nb_element; 
	short selection;	
	PROJ *suivant;
	double vect_x;
	double vect_y;
	double fin_x;
	double fin_y;
	double unit_x;
	double unit_y;
	double norme; 
	double normal_x;
	double normal_y;
};

static PROJ * p_tete = NULL; 
static int nb_proj = 0;


int projecteur_decodage(char *tab, int *ptr_nb_pr, int i)
{
	if(i == 0)
	{
		if(sscanf(tab,"%d", ptr_nb_pr) != NB_PROJ) 
		{
			error_lect_nb_elements(ERR_PROJECTEUR);  
			return 1;
		}
		nb_proj = *ptr_nb_pr;
		return 0;
	}
	
	PROJ * data = NULL;
	
	data = projecteur_liste_ajouter();
	data->nb_element = i;
	data->selection = FAUX;
	
	if(sscanf(tab, "%lf %lf %lf", &data->deb_x, &data->deb_y, &data->alpha) 
	   != NB_ELEM)
	{
		error_lecture_elements(ERR_PROJECTEUR, ERR_PAS_ASSEZ);
		return 1;
	}
	projecteur_coordonnees();
	return 0;
}

PROJ * projecteur_liste_ajouter()
{
	PROJ * e1 = NULL;
	if(!(e1 = malloc(sizeof(PROJ))))
	{
		printf("Pb d'allocation dans %s\n", __func__);
		exit(EXIT_FAILURE);
	}
	e1->suivant = p_tete;
	p_tete = e1;
	return e1;
}

int projecteur_creation(double x, double y, double alpha)
{
	int nb_pr = modele_nb_pr();
	static int i = 1;
	PROJ * data = NULL;
	double L = 0;
	L = (NBPH - 1) * EPSIL_PROJ;
	
	data = projecteur_liste_ajouter();
	data->deb_x = x;
	data->deb_y = y;
	data->alpha = alpha;
	data->fin_x = data->deb_x - L*sin(data->alpha);
	data->fin_y = data->deb_y + L*cos(data->alpha);
	data->nb_element = nb_proj + i; 
	data->selection = FAUX;
	
	nb_pr++;
	modele_modif_nb_element(nb_pr, PROJECTEUR);
	
	if(reflecteur_verification_2(data->deb_x, data->deb_y, data->fin_x, 
								 data->fin_y, PROJECTEUR, data->nb_element) ||
	   absorbeur_verification_2(data->deb_x, data->deb_y, data->fin_x, 
								data->fin_y, PROJECTEUR, data->nb_element))
	{
		data->selection = VRAI;
		projecteur_suppr_selectionne(nb_pr);
		return 1;
	}
	i++;
	return 0;
}

void projecteur_liste_retirer(PROJ *e1)
{
	PROJ * precedent = p_tete;
	PROJ * actuel = p_tete;
	
	while(actuel != e1 && actuel)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
}

void projecteur_vider_liste()
{
	/* Retire un à un les elements en tete de la liste */ 
	PROJ *e1;
	while (p_tete)
	{
		e1 = p_tete;
		projecteur_liste_retirer(e1);
	}
}

double projecteur_pt_plus_proche(double x, double y) 
{
	projecteur_deselection();
	
	// verifier si projecteur
	if(!p_tete)
		return 0; 
	
	PROJ *projecteur = p_tete;
	PROJ *a_supprimer = NULL;
	
	double d1 = 0, d2 = 0;
	double d_min = sqrt(pow((x - projecteur->deb_x),2) 
						+ pow((y - projecteur->deb_y),2));
	
	while(projecteur)
	{
		d1 = sqrt(pow((x - projecteur->deb_x),2) + pow((y - projecteur->deb_y),2));
		d2 = sqrt(pow((x - projecteur->fin_x),2) + pow((y - projecteur->fin_y),2));
		if(d1 <= d_min)
		{
			d_min = d1;
			a_supprimer = projecteur;
		}
		if(d2 <= d_min)
		{
			d_min = d2;
			a_supprimer = projecteur;
		}
		projecteur = projecteur->suivant;		
	}

	a_supprimer->selection = VRAI;
	return 1;
}

int projecteur_deselection()
{
	// verifier si projecteurs
	if(!p_tete)
		return 0;
		
	PROJ *projecteur;
	projecteur = p_tete;
	
	while(projecteur)
	{
		if ((projecteur->selection) == VRAI)
		{
			(projecteur->selection) = FAUX;
		}
		projecteur = projecteur->suivant;
	}
	
	return 0;
}

int projecteur_suppr_selectionne(nb_pr)
{
	// verifie si projecteur
	if(!p_tete)
		return 0;
		
	PROJ *projecteur;
	projecteur = p_tete;
	
	while(projecteur)
	{
		if (projecteur->selection == VRAI)
		{
			projecteur_supprimer(projecteur, nb_pr);
			return 0 ;
		}

		projecteur = (projecteur->suivant);
	}
	printf("projecteur_suppr_selectionne is called.\n");
	return 0;
}

int projecteur_supprimer(PROJ *a_supprimer, int nb_pr)
{
	// verifie si projecteur
	if(!p_tete)
		return 1;
		
	// cas où le projecteur est le premier element
	if(a_supprimer == p_tete)
	{
		p_tete = a_supprimer->suivant;
		free(a_supprimer);
		nb_pr--;
		modele_modif_nb_element(nb_pr, PROJECTEUR);
		return 1;
	}
		
	// autres cas
	PROJ *projecteur;
	projecteur = p_tete;
	
	while(projecteur)
	{
		if(projecteur->suivant == a_supprimer)
		{
			projecteur->suivant = a_supprimer->suivant;
			free(a_supprimer);
			nb_pr--;
			modele_modif_nb_element(nb_pr, PROJECTEUR);
			return 1;
		}
		projecteur = (projecteur->suivant);
	}
	return 0;
}


void projecteur_coordonnees ()
{
	PROJ * courant = p_tete;
	while(courant)
	{
		//lgr d'un projecteur
		double L = 0;
		L = (NBPH - 1) * EPSIL_PROJ;

		//trouver l'autre extrémité du vecteur_projecteur
		courant->fin_x = courant->deb_x - L*sin(courant->alpha); 
		courant->fin_y = courant->deb_y + L*cos(courant->alpha);
    
		//creation du vecteur PROJECTEUR
		projecteur_creation_vecteur(courant);
		
		courant = courant->suivant;
	}
}


void projecteur_creation_vecteur(PROJ * courant)
{
    courant->vect_x = courant->fin_x - courant->deb_x;
    courant->vect_y = courant->fin_y - courant->deb_y;
    
    courant->norme = sqrtf (pow (courant->vect_x, 2) + pow (courant->vect_y, 2));
    
    courant->unit_x = courant->vect_x / courant->norme;
    courant->unit_y = courant->vect_y / courant->norme;
  
    courant->normal_x = - courant->unit_y;
    courant->normal_y = courant->unit_x;
}


void projecteur_affichage()
{
	const float vert[3] = {0., 1., 0.};
	graphic_set_color3fv(vert);
	
	PROJ * actuel = p_tete;
	
	while(actuel)
	{
		if(actuel->selection == VRAI)
		{
			graphic_set_line_width(4.);
		}
		else
		{
			graphic_set_line_width(2.);
		}
		graphic_draw_segment (actuel->deb_x, actuel->deb_y, actuel->fin_x, 
							  actuel->fin_y);
		actuel = actuel->suivant;
	}
}

double * projecteur_renvoie_deb_x(int i)
{
	PROJ * projecteur = NULL;
	int compteur = 0;
	static double deb_x = 0;
	double * ptr_deb_x = NULL;
	
	if(p_tete)
	{
		projecteur = p_tete;
		while(compteur < i)
		{
			projecteur = projecteur->suivant;
			compteur++;
		}
		if(projecteur)
		{
			deb_x = projecteur->deb_x;  
			ptr_deb_x = &deb_x;
		}
	}
	return ptr_deb_x;
}

double * projecteur_renvoie_deb_y(int i)
{
	PROJ * projecteur = NULL;
	int compteur = 0;
	static double deb_y = 0;
	double * ptr_deb_y = NULL;
	
	if(p_tete)
	{
		projecteur = p_tete;
		while(compteur < i)
		{
			projecteur = projecteur->suivant;
			compteur++;
		}
		if(projecteur)
		{
			deb_y = projecteur->deb_y; 
			ptr_deb_y = &deb_y;
		}
	}

	return ptr_deb_y;
}

double projecteur_renvoie_alpha(int i)
{
	PROJ * projecteur = NULL;
	int compteur = 0;
	double alpha = 0;
	
	if(p_tete)
	{
		projecteur = p_tete;
		while(compteur < i)  
		{
			projecteur = projecteur->suivant;
			compteur++;
		}
		if(projecteur)
		{
			alpha = projecteur->alpha;
		}
		else alpha = 0;
	}
	else alpha = 0;
	
	return alpha;
}

/***********************************************************************/

void projecteur_get_lineseg(int *i, int *n, double *p1_x, double *p1_y, 
							double *p2_x, double *p2_y)
{
	PROJ * courant = p_tete;
	
	while (courant && courant->nb_element != *i) 
	{
		*p1_x = courant->deb_x;
		*p1_y = courant->deb_y;
		*p2_x = courant->fin_x;
		*p2_y = courant->fin_y;
		*n = courant->nb_element;
		courant = courant->suivant;
	}
	(*i)++;	
}

int projecteur_verification_2(double deb_x, double deb_y, double fin_x, 
							  double fin_y, int etat, int i)
{
	PROJ * actuel = p_tete;
	
	while(actuel)
	{
		if(utilitaire_superposition(deb_x, deb_y, fin_x, fin_y, actuel->deb_x,
								   actuel->deb_y, actuel->fin_x, actuel->fin_y, 
								   EPSIL_CREATION))
			{
				error_lecture_intersection(etat, i-1, ERR_PROJECTEUR, 
										   actuel->nb_element-1); 
				return 1;               
			}
			actuel = actuel->suivant;
	}
	return 0;
}

void save_proj(FILE *fichier)
{
	PROJ * actuel = p_tete;
	
	fprintf(fichier, "#projecteurs\n");
	if(actuel)
	{
		fprintf (fichier, "%d\n", actuel->nb_element); 
	}
	while(actuel)
	{
		fprintf(fichier, "%f %f %f\n", actuel->deb_x, actuel->deb_y, actuel->alpha);
		actuel = actuel->suivant;
	}
	fprintf(fichier, "FIN_LISTE\n\n");
}

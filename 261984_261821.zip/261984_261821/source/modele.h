#ifndef MODELE_H
#define MODELE_H

#include <stdio.h>
#include <stdlib.h>
#define NB_ELEM2 4

typedef struct nb_element NB_ELEMENT;
enum Etat_lecture {PROJECTEUR, REFLECTEUR, ABSORBEUR, PHOTON, FIN_LISTE, 
				   ERREUR, CREATION};

// fonctions de décodage des fichiers texte
int modele_lecture(char * nom_fichier);
int modele_decodage_ligne(char * tab);
int modele_fin_liste(int *j, int *i, int *etat, char *tab);
int modele_entite(char * tab, int *ptr_nb, int etat, int i);

void modele_remise_a_zero(int *ptr_i, int *ptr_j, int *ptr_etat);

// fonctions pour récupérer les valeurs nb_pr, etc.
int modele_nb_pr();
int modele_nb_r();
int modele_nb_a();
int modele_nb_ph();
void modele_modif_nb_element(int nb, int etat);
void modele_nb_elem(int nb_elem[NB_ELEM2]);

void modele_listes_effacer();
void modele_affichage(short actif, double deb_x, double deb_y, double fin_x, 
					  double fin_y);
					  
// fonction pour supprimer les photons hors cadre
void modele_supp_hors_cadre(double x_max, double x_min, double y_max, 
						    double y_min);
						    
// fonctions de sélection, de suppression et de déselection
int modele_pt_plus_proche(int live_entity, double x_pos, double y_pos);
void modele_suppr_selectionne(int etat);
void modele_deselection(int etat);

// fonctions de création des entités
int modele_creation_elem(int etat, double mdeb_x, double mdeb_y, double mfin_x, 
						 double mfin_y);
int modele_creation_absorbeur(double deb_x, double deb_y, short *debcreation);
void modele_creation_nveau_photon();

// fonction de vérification des intersections entre entités
int modele_verification_rendu2();

// fonction pour sauvegarder les données dans un fichier texte
void modele_save (char * text_sortie);

// fonction de mise a jour de la simulation
void modele_maj();

// stubs
void modele_sim_update();
void modele_one_step();
void modele_sim_elem_release();

#endif

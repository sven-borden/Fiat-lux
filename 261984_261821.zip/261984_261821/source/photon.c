// fichier: photon.c
// date: 08.04.2016
// description du module: fonctions liées aux photons
//-------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "absorbeur.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "modele.h" 
#include "photon.h"
#include "projecteur.h"
#include "reflecteur.h"
#include "utilitaire.h" 
#define NB_COOR 	3
#define NB_PHOT 	1
#define PI     		3.1415
#define D_PI     	1.57075 // demi pi
#define DIST_MIN	10


struct phot{
	double deb_x;
	double deb_y;
	double fin_x;   
	double fin_y;
	double alpha;
	int nb_element; 
	PHOT *suivant;
};

static PHOT * p_tete = NULL;
static int nb_phot = 0;


int photon_decodage(char *tab, int *ptr_nb_ph, int i)
{
	if(i == 0)
	{
		if(sscanf(tab,"%d", ptr_nb_ph) != NB_PHOT) 
		{
			error_lect_nb_elements(ERR_PHOTON); 
			return 1;
		}
		nb_phot = *ptr_nb_ph;
		return 0;
	}
	
	PHOT * data = NULL;
	
	data = photon_liste_ajouter();
	data->nb_element = i;
	
	if(sscanf(tab, "%lf %lf %lf", &data->deb_x, &data->deb_y, &data->alpha) 
	   != NB_COOR) 
	{
		error_lecture_elements(ERR_PHOTON, ERR_PAS_ASSEZ);
		return 1;
	}
	return 0;
}

PHOT * photon_liste_ajouter()
{
	PHOT * e1 = NULL;
	if(!(e1 = malloc(sizeof(PHOT))))
	{
		printf("Pb d'allocation dans %s\n", __func__);
		exit(EXIT_FAILURE);
	}
	e1->suivant = p_tete;
	p_tete = e1;
	return e1;
}

void photon_creation(double x, double y, double alpha)
{
	static int i = 1;
	int nb_ph = modele_nb_ph();
	PHOT * data = NULL;
	
	data = photon_liste_ajouter();
	data->deb_x = x;
	data->deb_y = y;
	data->alpha = alpha;
	data->nb_element = nb_phot + i; 
	nb_ph++;
	modele_modif_nb_element(nb_ph, PHOTON);
	i++;
}

void photon_liste_retirer(PHOT *e1)
{
	PHOT * precedent = p_tete;
	PHOT * actuel = p_tete;
	
	while(actuel != e1 && actuel)
	{
		precedent = actuel;
		actuel = actuel->suivant;
	}
	if(actuel)
	{
		if(actuel != p_tete)
		{
			precedent->suivant = actuel->suivant;
			free(actuel);
		}
		else
		{
			p_tete = actuel->suivant;
			free(actuel);
		}
	}
}

void photon_vider_liste()
{
	/* Retire un à un les elements en tete de la liste */ 
	PHOT *e1;
	while (p_tete)
	{
		e1 = p_tete;
		photon_liste_retirer(e1);
	}
}


void photon_affichage()
{
	const float noir[3] = {0., 0., 0.};
	graphic_set_color3fv(noir);
	graphic_set_line_width(1.);
	
	PHOT * actuel = p_tete;
	float r = EPSIL_PROJ/2;
	
	while(actuel)
	{	
		graphic_draw_circle (actuel->deb_x, actuel->deb_y, r);
		actuel = actuel->suivant;
	}
}

void photon_supprimer_hors_cadre(double x_max, double x_min, 
								 double y_max, double y_min) 
{
	int nb_ph = modele_nb_ph();
	PHOT * tete = p_tete;
	
	if(tete)
	{
		while(tete && (tete->deb_x < x_min || tete->deb_x > x_max
			  || tete->deb_y < y_min || tete->deb_y > y_max))
		{
			p_tete = tete->suivant;
			free(tete);
			tete = p_tete;
			nb_ph--;
		}
		
		PHOT * precedent = tete;
		while(precedent && precedent->suivant)
		{
			if(precedent->suivant->deb_x < x_min || 
			   precedent->suivant->deb_x > x_max || 
			   precedent->suivant->deb_y < y_min || 
			   precedent->suivant->deb_y > y_max)
			{
				PHOT * a_retirer = precedent->suivant;
				precedent->suivant = precedent->suivant->suivant;
				free(a_retirer);
				nb_ph--;
			}
			else precedent = precedent->suivant;
		}
	}
	modele_modif_nb_element(nb_ph, PHOTON);
}

void photon_supprimer(int id)
{
	PHOT * tete = p_tete;
	
	if(tete) // liste non-vide
	{
		if(tete->nb_element == id)
		{
			p_tete = tete->suivant;
			free(tete);
		}
		else
		{
			PHOT * precedent = tete;
			while((precedent->suivant && 
				   precedent->suivant->nb_element != id ))  // recherche
				precedent = precedent->suivant;
				
			if(precedent->suivant) // trouvé 
			{
				PHOT * a_retirer = precedent->suivant;
				precedent->suivant = precedent->suivant->suivant;
				free(a_retirer);
			}
		}
	}
}


void save_phot(FILE * fichier)
{
	PHOT * actuel = p_tete;
	fprintf(fichier, "#photons\n");
	
	if(actuel)
	{
		fprintf (fichier, "%d\n", actuel->nb_element);
	}
	while(actuel)
	{
		fprintf(fichier, "%f %f %f \n", actuel->deb_x, actuel->deb_y, actuel->alpha);
		actuel = actuel->suivant;
	}
	
	fprintf(fichier, "FIN_LISTE");
}


/****************************************************************************/
void photon_coordonnees ()
{
	PHOT * actuel = p_tete;
	
	while(actuel)
	{
		//lgr d'un projecteur
		double L = 0;
		L = VPHOT*DELTA_T;
		
		//trouver l'autre extrémité du vecteur_projecteur
		actuel->fin_x = actuel->deb_x + L*cos(actuel->alpha);
		actuel->fin_y = actuel->deb_y + L*sin(actuel->alpha);

		actuel = actuel->suivant;
	}
}

double determinant(double x1, double y1, double x2, double y2)
{
	return x2 * y1 - y2 * x1;
}

	
void photon_intersection (double deb_x, double deb_y, double fin_x, 
						  double fin_y, double r1_x, double r1_y, double r2_x, 
						  double r2_y, double *x, double *y)
{
	VECTEUR v_r = utilitaire_coor_vecteur(r1_x, r1_y, r2_x, r2_y);
	VECTEUR v_ph = utilitaire_coor_vecteur(deb_x, deb_y, fin_x, fin_y);
		
	if(v_r.x == 0)
		v_r.x = 1e-08;
	
	double pv_phr = utilitaire_produit_vectoriel(v_r, v_ph); 
	double det_r = determinant (r1_x, r1_y, r2_x, r2_y);
	double det_ph = determinant (deb_x, deb_y, fin_x, fin_y);

	*x = (v_ph.x * det_r - v_r.x*det_ph) / pv_phr;
	*y = (v_r.y/v_r.x)*(*x) + (det_r/v_r.x);
}


double photon_distance_reflecteur(double x, double y, double ph_x, double ph_y)
{
	return sqrt (pow ((x - ph_x),2) + pow((y - ph_y),2)); 
}


VECTEUR photon_suivant_coor(double l1, double x1, double y1, VECTEUR w, double L)
{
	double l2 = L - l1;

	VECTEUR nvx = {x1 + l2*w.x, y1 + l2*w.y};
	return nvx;
}

void photon_angle(PHOT **actuel, double x1, double y1, double x2, double y2)
{
	PHOT *actuel2 = *actuel;
	
	double angle_r = atan2((y2 - y1),(x2 - x1));
	
	actuel2->alpha = 2*angle_r - actuel2->alpha;
}

void photon_test_reflecteur (PHOT **actuel, double r1_x, double r1_y, 
							 double r2_x, double r2_y,double L)
{
	double x1 = 0, y1 = 0;
	double l1 = 0;
	
	PHOT * actuel2 = *actuel;

	VECTEUR v_ph = utilitaire_coor_vecteur(actuel2->deb_x, actuel2->deb_y,
											actuel2->fin_x, actuel2->fin_y);
	
	double norm_ph = utilitaire_norm(v_ph);
	VECTEUR t = utilitaire_unitaire(v_ph, norm_ph);
	
	//calcul de n 
	VECTEUR v_r = utilitaire_coor_vecteur(r1_x, r1_y, r2_x, r2_y);
	
	double norm_r = utilitaire_norm(v_r);
	VECTEUR u_r = utilitaire_unitaire(v_r, norm_r);
	VECTEUR n = utilitaire_normal(u_r); 
	
	//calcul de w unitaire 
	double tn = utilitaire_produit_scalaire(t, n);
	if (tn > 0)
	{
		n.x = u_r.y;
		n.y = - u_r.x; 
		tn = utilitaire_produit_scalaire(t, n);
	}
	
	VECTEUR w1 = {t.x - 2*tn*n.x, t.y - 2*tn*n.y}; 
	double norm_w = utilitaire_norm(w1);
	VECTEUR w = utilitaire_unitaire(w1, norm_w);
	
	//distance photon/reflecteur
	photon_intersection(actuel2->deb_x, actuel2->deb_y, actuel2->fin_x, 
						actuel2->fin_y, r1_x, r1_y, r2_x, r2_y, &x1, &y1);
	l1 = photon_distance_reflecteur(x1, y1, actuel2->deb_x, actuel2->deb_y);
	
	VECTEUR ph = photon_suivant_coor(l1, x1, y1, w, L);
	//mise à jour des valeurs
	actuel2->deb_x = ph.x; 
	actuel2->deb_y = ph.y;	

	photon_angle(&actuel2, r1_x, r1_y, r2_x, r2_y);		
}

void photon_final_reflechi()
{
	PHOT * actuel = p_tete;
	double d_r = DIST_MIN, d_a = DIST_MIN;
	//coor et num du refl et abso le plus proche
	double r_deb_x = 0, r_deb_y = 0, r_fin_x = 0, r_fin_y = 0;
	static int a = 0;
	int valeur = 0, cas_critique = 0; 
	int nb_ph = modele_nb_ph();

	photon_coordonnees ();
	
	double L = 0;
	L = VPHOT * DELTA_T;
	
	
	while(actuel)
	{
		cas_critique = 0;
		d_r = d_a = DIST_MIN;

		valeur += reflecteur_verification_2(actuel->deb_x, actuel->deb_y, 
											actuel->fin_x, actuel->fin_y,5,0, 
											&d_r, 1, &r_deb_x, &r_deb_y, 
											&r_fin_x, &r_fin_y, &cas_critique);
		valeur += absorbeur_verification_2(actuel->deb_x, actuel->deb_y, 
										   actuel->fin_x, actuel->fin_y, 
										   0, 0, &d_a, 1);
		
		// comparaison distance refl et abso
		if (d_r < d_a && valeur != 0 && cas_critique == 0) // refl plus proche
		{
			photon_test_reflecteur (&actuel, r_deb_x, r_deb_y, r_fin_x, 
									r_fin_y, L);
		}
		else if (d_r > d_a && valeur != 0 && cas_critique == 0)
		{
			photon_supprimer(actuel->nb_element);
			modele_modif_nb_element(nb_ph, PHOTON);
		}
		else if (valeur == 0 || cas_critique == 1)
		{
			actuel->deb_x = actuel->fin_x;
			actuel->deb_y = actuel->fin_y;
		}
		actuel = actuel->suivant;
		valeur = 0; 
	}
	a++;
}

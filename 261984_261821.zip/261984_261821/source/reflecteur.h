#ifndef REFLECTEUR_H
#define REFLECTEUR_H

#include <stdio.h>
#include <stdlib.h>

typedef struct refl REFL;

// fonction de décodage du fichier texte
int reflecteur_decodage(char *tab, int *ptr_nb_r, int i);

REFL * reflecteur_liste_ajouter();
void reflecteur_liste_retirer(REFL *e1);
void reflecteur_vider_liste();

// fonctions de sélection, de suppression et de création
int reflecteur_creation(double deb_x, double deb_y, double fin_x, double fin_y);
double reflecteur_pt_plus_proche(double x, double y);
void reflecteur_selection();
int reflecteur_deselection();
int reflecteur_suppr_selectionne(int nb_r);
int reflecteur_supprimer(REFL *a_supprimer, int nb_r);

// fonction d'affichage dans la fenêtre
void reflecteur_affichage();

// fonctions de calcul ou qui renvoient des valeurs pour la mise à jour
void reflecteur_creation_vecteur ();
void reflecteur_get_lineseg(int *i, int *m, double *r1_x, double *r1_y, 
							double *r2_x, double *r2_y);
short reflecteur_verification(int nb_r);
int reflecteur_verification_2(double deb_x, double deb_y, double fin_x, 
							  double fin_y, int etat, int i);
int reflecteur_verification_3(double deb_x, double deb_y, double fin_x, 
					          double fin_y, int etat, int i, double *d_r, 
							  double *r_deb_x, double *r_deb_y, 
					          double *r_fin_x, double *r_fin_y, int *cas_critique);
							  
// fonction de sauvegarde dans un fichier texte
void save_refl(FILE * fichier);

#endif

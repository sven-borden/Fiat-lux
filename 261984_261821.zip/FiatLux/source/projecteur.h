#ifndef PROJECTEUR_H
#define PROJECTEUR_H

int decodage_nb_pr(char *tab, int *ptr_nb_pr);
int projecteur(char *tab, int i);

#endif

#ifndef UTILITAIRE_H
#define UTILITAIRE_H

double points_trop_proche(double x1, double y1, double x2, double y2);

#endif

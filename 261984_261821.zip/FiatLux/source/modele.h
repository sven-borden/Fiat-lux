#ifndef MODELE_H
#define MODELE_H

int lecture_modele(char * nom_fichier);
int decodage_ligne(char * tab);

#endif

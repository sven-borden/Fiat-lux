#ifndef ABSORBEUR_H
#define ABSORBEUR_H

int decodage_nb_a(char *tab, int *ptr_nb_a);
int absorbeur(char *tab, int i);

#endif

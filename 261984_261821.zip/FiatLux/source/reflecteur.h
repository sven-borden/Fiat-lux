#ifndef REFLECTEUR_H
#define REFLECTEUR_H

int decodage_nb_r(char *tab, int *ptr_nb_r);
int reflecteur(char *tab, int i);

#endif

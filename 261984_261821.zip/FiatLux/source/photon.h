#ifndef PHOTON_H
#define PHOTON_H

int decodage_nb_ph(char *tab, int *ptr_nb_ph);
int photon(char *tab, int i);

#endif
